import { useState, useEffect, useMemo } from 'react'
import { dbKvGet, dbKvSet, AI_GATEWAY } from './api'
import { toast } from './utils'

const TEAM_PROMPTS_KV_KEY = 'team_prompts_sync:v1'
const LOCAL_STORAGE_KEY = 'kem-con-hoc:team-prompts-cache'
const LAST_AUTHOR_KEY = 'kem-con-hoc:team-author'

// Danh mục prompt phổ biến
export const PROMPT_CATEGORIES = [
  { id: 'all', name: 'Tất cả danh mục', icon: '📂' },
  { id: 'math', name: 'Toán tiểu học', icon: '📐' },
  { id: 'vietnamese', name: 'Tiếng Việt', icon: '📖' },
  { id: 'english', name: 'Tiếng Anh', icon: '🇬🇧' },
  { id: 'vision_ocr', name: 'Vision & OCR', icon: '📷' },
  { id: 'socratic', name: 'Sư phạm Socratic', icon: '💡' },
  { id: 'practice', name: 'Luyện tập mở rộng', icon: '✏️' },
  { id: 'other', name: 'Khác', icon: '🧪' },
]

// Models AI công ty phổ biến
export const COMPANY_AI_MODELS = [
  'Claude 3.7 Sonnet',
  'Claude 3.5 Sonnet',
  'ChatGPT GPT-4o',
  'GPT-4o-mini',
  'Company Internal AI (Private)',
  'Llama 3.3 70B',
  'Gemini 1.5 Pro',
  'Khác (Tùy chọn)',
]

// Dữ liệu mẫu khởi tạo ban đầu để team thấy ngay nội dung thực tế
const INITIAL_TEAM_PROMPTS = [
  {
    id: 'tp_longitudinal_1',
    title: 'Prompt Full Triển Khai Kỹ Thuật: Big Data Sticker, FontAwesome Tone-Sur-Tone & AI Adaptive Roadmap',
    category: 'math',
    targetAi: 'VideFlow',
    author: 'Huyền (Tech Lead)',
    isRunCompanyAi: true,
    runBy: 'VideFlow',
    runAt: '2026-10-23 16:50',
    aiResult: 'Đã chạy hoàn tất trên VideFlow. Toàn bộ mã nguồn FontAwesome tone-sur-tone, Big Data sticker history và AI Adaptive Roadmap đã được build và deploy live thành công lên Cloudflare Pages.',
    promptDetail: `Bạn là chuyên gia Full-stack AI & Frontend React/Vite cấp cao. Nhiệm vụ của bạn là kiểm tra, hoàn thiện và nâng cấp toàn diện tính năng **Hệ Thống Huy Hiệu Phẩm Chất FontAwesome Tone-Sur-Tone, Big Data Lịch Sử Sticker Dài Hạn & AI Adaptive Roadmap** cho ứng dụng Web React (Vite) "Kèm Con Học".

---

### BỐI CẢNH VÀ VẤN ĐỀ CỐT LÕI CẦN NÂNG CẤP:

1. **Vấn đề 1 (Thẩm mỹ & Giao diện Icon lung tung):**
   - Hiện tại ứng dụng đang dùng các emoji rải rác, màu sắc chữ và huy hiệu chưa đồng bộ tone-sur-tone. Đối với trẻ con thì dùng emoji tạm ổn, nhưng để đạt chuẩn thẩm mỹ cao cấp, chỉn chu và tạo sự chuyên nghiệp cho sản phẩm giáo dục, hệ thống phải chuyển sang bộ icon **FontAwesome 6** với bảng màu tone-sur-tone định hình rõ từng phẩm chất (Kiên nhẫn, Sáng tạo, Tốc độ, Tỉ mỉ, Tập trung,...).

2. **Vấn đề 2 (Mất sạch Big Data lịch sử khi đổi quà):**
   - Hiện tại logic của app chỉ tích lũy đủ 10 sticker là đổi quà, sau khi đổi quà thì mảng sticker bị reset về 0. Điều này làm mất toàn bộ dữ liệu lịch sử theo thời gian (Longitudinal History) khiến hệ thống không có "Big Data" để phân tích sự phát triển phẩm chất của con qua các tuần.
   - Ví dụ thực tế: Tuần 1 con nhận được 3 sticker Kiên nhẫn, 5 sticker Sáng tạo; nhưng sang Tuần 2 con chỉ nhận được 1 Sáng tạo và tận 4 Kiên nhẫn. Nếu không lưu vĩnh viễn, AI không thể nhận diện được sự biến động này.

3. **Vấn đề 3 (Thiếu AI phân tích nguyên nhân & Lộ trình sư phạm thích ứng):**
   - Cần đưa AI vào phân tích Big Data tóm tắt: Tại sao Sáng tạo lại giảm sút? Do dạng bài tập tuần này quá nhàm chán/rập khuôn công thức, hay do độ khó bài học đột ngột tăng vọt khiến con phải dồn sức kiên nhẫn vượt khó?
   - Tương tự với các môn học: Môn nào con vướng nhiều? Từ đó AI đề xuất một **Lộ trình 7 ngày cân bằng (Adaptive Roadmap)** gửi cho phụ huynh ở màn hình Báo cáo (\`Report\`) và hiển thị thống kê tổng quan ở trang Admin (\`Admin Analytics\`).

---

### HƯỚNG DẪN KỸ THUẬT & CODE IMPLEMENT CHI TIẾT TỪNG BƯỚC:

#### BƯỚC 1: TÍCH HỢP FONTAWESOME 6 VÀO \`index.html\`
Thêm link CDN FontAwesome 6 vào thẻ \`<head>\` của \`index.html\`:
\`\`\`html
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />
\`\`\`

---

#### BƯỚC 2: CHUẨN HÓA BẢNG DỮ LIỆU HUY HIỆU & MOCK HISTORY TRONG \`src/data.js\`
1. Cập nhật mảng \`AVAILABLE_STICKERS\`:
   Mỗi sticker phải có: \`id\`, \`trait\` (phẩm chất), \`n\` (tên hiển thị), \`fa\` (icon FontAwesome class), \`color\`, \`bg\`, \`border\`, \`desc\`:
   - Kỳ lân Kiên trì: \`trait: 'Kiên nhẫn'\`, \`fa: 'fa-solid fa-mountain'\`, \`color: '#7C3AED'\`, \`bg: '#F5F3FF'\`, \`border: '#DDD6FE'\`.
   - Tên lửa Tốc độ: \`trait: 'Tốc độ'\`, \`fa: 'fa-solid fa-bolt-lightning'\`, \`color: '#EA580C'\`, \`bg: '#FFF7ED'\`, \`border: '#FED7AA'\`.
   - Ngôi sao Sáng tạo: \`trait: 'Sáng tạo'\`, \`fa: 'fa-solid fa-lightbulb'\`, \`color: '#D97706'\`, \`bg: '#FFFBEB'\`, \`border: '#FDE68A'\`.
   - Gấu trúc Tỉ mỉ: \`trait: 'Tỉ mỉ'\`, \`fa: 'fa-solid fa-compass-drafting'\`, \`color: '#059669'\`, \`bg: '#ECFDF5'\`, \`border: '#A7F3D0'\`.
   - Sư tử Tự tin: \`trait: 'Tự tin'\`, \`fa: 'fa-solid fa-shield-heart'\`, \`color: '#DC2626'\`, \`bg: '#FEF2F2'\`, \`border: '#FECACA'\`.
   - Cầu vồng Vui vẻ: \`trait: 'Vui vẻ'\`, \`fa: 'fa-solid fa-face-smile-beam'\`, \`color: '#DB2777'\`, \`bg: '#FDF2F8'\`, \`border: '#FBCFE8'\`.
   - Cá heo Thông thái: \`trait: 'Thông thái'\`, \`fa: 'fa-solid fa-book-open-reader'\`, \`color: '#0284C7'\`, \`bg: '#F0F9FF'\`, \`border: '#BAE6FD'\`.
   - Vương miện Tập trung: \`trait: 'Tập trung'\`, \`fa: 'fa-solid fa-bullseye'\`, \`color: '#4F46E5'\`, \`bg: '#EEF2FF'\`, \`border: '#C7D2FE'\`.
   - Ong vàng Chăm chỉ: \`trait: 'Chăm chỉ'\`, \`fa: 'fa-solid fa-clock-rotate-left'\`, \`color: '#B45309'\`, \`bg: '#FEF3C7'\`, \`border: '#FDE68A'\`.
   - Cú mèo Tư duy: \`trait: 'Tư duy'\`, \`fa: 'fa-solid fa-brain'\`, \`color: '#6366F1'\`, \`bg: '#F5F3FF'\`, \`border: '#E0E7FF'\`.
   - Rùa con Bền bỉ: \`trait: 'Bền bỉ'\`, \`fa: 'fa-solid fa-shoe-prints'\`, \`color: '#16A34A'\`, \`bg: '#F0FDF4'\`, \`border: '#BBF7D0'\`.
   - Cúp Vô địch Tuần: \`trait: 'Xuất sắc'\`, \`fa: 'fa-solid fa-trophy'\`, \`color: '#CA8A04'\`, \`bg: '#FEFCE8'\`, \`border: '#FEF08A'\`.

2. Thêm dữ liệu mẫu \`SAMPLE_STICKER_HISTORY\` để phục vụ phân tích đa tuần:
   - Tuần trước: 5 Sáng tạo, 3 Kiên nhẫn (bài toán khởi động, dễ).
   - Tuần này: 1 Sáng tạo, 4 Kiên nhẫn, 1 Tập trung, 1 Tỉ mỉ (bài toán lời văn 2 bước khó).

---

#### BƯỚC 3: CƠ CHẾ LƯU VĨNH VIỄN & KHÔNG RESET KHI ĐỔI QUÀ (\`src/App.jsx\` & \`src/screens.jsx\`)
1. Trong \`defaultStats\` (\`src/App.jsx\`):
   Khởi tạo \`stickerHistory: [...SAMPLE_STICKER_HISTORY]\`.

2. Trong \`Done()\` (\`src/screens.jsx\`), sửa hàm \`pickSticker(e)\`:
   - Append huy hiệu được chọn vào \`stats.stickersList\` (dùng để đếm mốc 10 sticker đổi quà).
   - ĐỒNG THỜI tạo một record mới và append vào \`stats.stickerHistory\`:
     \`\`\`javascript
     const newHistoryItem = {
       id: 'h_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4),
       stickerId: found.id,
       name: found.n,
       trait: found.trait || 'Kiên nhẫn',
       fa: found.fa || 'fa-solid fa-award',
       color: found.color || '#F59E0B',
       subject: problem?.mon || 'Toán',
       problemType: problem?.dang_bai || 'Bài tập rèn luyện',
       week: 'Tuần này',
       timestamp: Date.now(),
       dateStr: new Date().toLocaleDateString('vi-VN'),
     }
     setStats({
       stickers: newList.length,
       stickersList: newList,
       stickerHistory: [...(stats.stickerHistory || []), newHistoryItem]
     })
     \`\`\`

3. Trong \`RewardSheet\` (\`src/App.jsx\`), khi phụ huynh bấm "Xác nhận đổi quà cho con":
   - Chỉ reset: \`stickers: 0\`, \`stickersList: []\`.
   - Tăng \`rewardCount: (curStats.rewardCount || 0) + 1\`.
   - TUYỆT ĐỐI KHÔNG xóa \`stickerHistory\`. Lịch sử sticker này là dữ liệu Big Data vĩnh viễn của học sinh.

---

#### BƯỚC 4: HÀM API AI PHÂN TÍCH LỘ TRÌNH DÀI HẠN (\`src/api.js\`)
Triển khai hàm \`aiAnalyzeLongitudinalProgress({ child, stats, stickerHistory = [] })\`:
\`\`\`javascript
export async function aiAnalyzeLongitudinalProgress({ child, stats, stickerHistory = [] }) {
  const thisWeek = stickerHistory.filter((s) => s.week === 'Tuần này')
  const lastWeek = stickerHistory.filter((s) => s.week === 'Tuần trước')

  const countTraits = (list) => {
    const map = {}
    list.forEach((s) => {
      const t = s.trait || s.name || 'Khác'
      map[t] = (map[t] || 0) + 1
    })
    return Object.entries(map).map(([k, v]) => \`\${v} sticker \${k}\`).join(', ') || 'Chưa có sticker'
  }

  const thongKeTuanNay = countTraits(thisWeek)
  const thongKeTuanTruoc = countTraits(lastWeek)
  const weakList = (stats?.weak || []).map((w) => \`\${w.n}: vướng \${w.v}/\${w.t} lần\`).join('; ') || 'Chưa có dạng bài vướng'
  const strongList = (stats?.strong || []).map((s) => \`\${s.n}: làm tốt \${s.v}/\${s.t}\`).join('; ') || 'Đang tiến bộ đều'
  const monHocVaVuongMac = \`Điểm vướng: \${weakList}. Điểm vững: \${strongList}\`
  const soCaHoc = \`Mẹ kèm \${stats?.sessionsMom || 0} ca, Bố kèm \${stats?.sessionsDad || 0} ca. Phụ huynh bấm giữ bình tĩnh \${stats?.calmWeek || 0} lần.\`

  const sysPrompt = renderPrompt('p7_longitudinal_analysis', {
    ten_be: child?.name || 'Bé',
    lop: child?.grade || 'Lớp 3',
    thong_ke_tuan_nay: thongKeTuanNay,
    thong_ke_tuan_truoc: thongKeTuanTruoc,
    mon_hoc_va_vuong_mac: monHocVaVuongMac,
    so_ca_hoc: soCaHoc,
  })

  try {
    const j = await postAi(
      '/chat',
      {
        messages: [
          { role: 'system', content: sysPrompt },
          { role: 'user', content: 'Hãy phân tích dữ liệu biến động phẩm chất và đề xuất lộ trình sư phạm cho con.' },
        ],
        max_tokens: 1200,
        temperature: 0.4,
      },
      30000
    )
    const resp = j?.response
    if (typeof resp === 'string' && resp.trim()) return resp.trim()
    return null
  } catch (e) {
    console.warn('Longitudinal analysis failed:', e)
    return null
  }
}
\`\`\`

---

#### BƯỚC 5: NÂNG CẤP MÀN HÌNH BÁO CÁO PHỤ HUYNH (\`Report()\` TRONG \`src/screens.jsx\`)
1. **Khối AI Adaptive Roadmap:**
   - Thêm nút: \`✨ AI Phân Tích Lộ Trình Cân Bằng (Big Data)\`.
   - Khi bấm: gọi \`aiAnalyzeLongitudinalProgress\`.
   - Kết quả trả về chia 3 phần rõ ràng:
     - 🔍 **1. Chẩn đoán biến động phẩm chất**: Giải thích nguyên nhân tại sao Sáng tạo giảm (do bài toán có lời văn 2 bước rập khuôn mẫu giải) và Kiên nhẫn tăng (con phải gắng sức vượt khó).
     - 📊 **2. Điểm nghẽn môn học & dạng bài**: Nêu dạng bài vướng mắc cần lưu tâm.
     - 🎯 **3. Lộ trình 7 ngày cân bằng (Adaptive Roadmap)**: Hoạt động cụ thể (5 que tính, xếp Lego, đổi người kèm sang Bố 1 buổi để kích hoạt lại cảm hứng sáng tạo).
2. **Khối So Sánh Biến Động Phẩm Chất (Longitudinal Trait Tracker):**
   - 4 card tone-sur-tone FontAwesome: Kiên nhẫn, Sáng tạo, Tập trung, Tỉ mỉ.
   - Hiển thị số lượng Tuần này vs Tuần trước kèm badge biến động: \`+1 ↗\`, \`-4 ↘\`, \`Đều\`.

\`\`\`jsx
export function Report() {
  const { S, stats, toast, boom } = useContext(AppCtx)
  const child = S.children.find((c) => c.id === S.activeId)
  const momDays = S.schedule.filter((d) => d.owner === 'Mẹ').length
  const dadDays = S.schedule.filter((d) => d.owner === 'Bố').length
  const total = momDays + dadDays
  const momPct = total ? Math.round((momDays / total) * 100) : 0
  const dadPct = 100 - momPct

  // Phân tích Big Data Sticker History
  const stickerHistory = stats.stickerHistory || []
  const thisWeekStickers = stickerHistory.filter((s) => s.week === 'Tuần này')
  const lastWeekStickers = stickerHistory.filter((s) => s.week === 'Tuần trước')

  const countTraitMap = (list) => {
    const map = {}
    list.forEach((s) => {
      const trait = s.trait || 'Kiên nhẫn'
      map[trait] = (map[trait] || 0) + 1
    })
    return map
  }

  const thisTraits = countTraitMap(thisWeekStickers)
  const lastTraits = countTraitMap(lastWeekStickers)

  const TRACKED_TRAITS = [
    { trait: 'Kiên nhẫn', fa: 'fa-solid fa-mountain', color: '#7C3AED', bg: '#F5F3FF', border: '#DDD6FE' },
    { trait: 'Sáng tạo', fa: 'fa-solid fa-lightbulb', color: '#D97706', bg: '#FFFBEB', border: '#FDE68A' },
    { trait: 'Tập trung', fa: 'fa-solid fa-bullseye', color: '#4F46E5', bg: '#EEF2FF', border: '#C7D2FE' },
    { trait: 'Tỉ mỉ', fa: 'fa-solid fa-compass-drafting', color: '#059669', bg: '#ECFDF5', border: '#A7F3D0' },
  ]

  const [aiAnalysis, setAiAnalysis] = useState(null)
  const [analyzing, setAnalyzing] = useState(false)

  const handleRunAiAnalysis = async () => {
    soundPop(550)
    setAnalyzing(true)
    toast('AI đang phân tích biến động phẩm chất & đề xuất lộ trình… 🧠')
    try {
      const result = await aiAnalyzeLongitudinalProgress({ child, stats, stickerHistory })
      if (result) {
        setAiAnalysis(result)
        soundSuccess()
        boom()
        toast('Đã có báo cáo lộ trình cân bằng cho con! ✨')
      }
    } catch (e) {
      toast('Lỗi kết nối AI, vui lòng thử lại sau.')
    } finally {
      setAnalyzing(false)
    }
  }

  return (
    <>
      <Header title={\`Tuần này của \${child.name}\`} />
      <p className="sub">{total} ca · mẹ kèm {momDays} ca, bố kèm {dadDays} ca · {stickerHistory.length} mốc dữ liệu phẩm chất</p>

      {/* 1. AI Phân tích Lộ trình Sư phạm & Biến động phẩm chất */}
      <div className="card pop" style={{ border: '2px solid #8B5CF6', background: 'linear-gradient(145deg, #FAF5FF 0%, #F3E8FF 100%)', padding: '16px 14px' }}>
        <b style={{ fontSize: 16, color: '#4C1D95', display: 'block', marginBottom: 6 }}>
          Phân Tích Biến Động Phẩm Chất & Lộ Trình Cân Bằng
        </b>
        {aiAnalysis && (
          <div style={{ background: '#FFFFFF', borderRadius: 14, padding: '14px 12px', border: '1.5px solid #DDD6FE', fontSize: 13.5, lineHeight: 1.55, color: '#1E293B', marginBottom: 12, whiteSpace: 'pre-wrap' }}>
            {aiAnalysis}
          </div>
        )}
        <button
          className="btn solid"
          disabled={analyzing}
          onClick={handleRunAiAnalysis}
          style={{ width: '100%', background: 'linear-gradient(135deg, #7C3AED 0%, #6D28D9 100%)', fontWeight: 800, fontSize: 14 }}
        >
          {analyzing ? 'Đang phân tích Big Data…' : '✨ AI Phân Tích Lộ Trình Cân Bằng Cho Con'}
        </button>
      </div>

      {/* 2. So sánh Biến động Phẩm chất Tuần này vs Tuần trước */}
      <div className="card">
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 10 }}>
          {TRACKED_TRAITS.map((item) => {
            const thisCnt = thisTraits[item.trait] || 0
            const lastCnt = lastTraits[item.trait] || 0
            const diff = thisCnt - lastCnt
            return (
              <div key={item.trait} style={{ background: item.bg, border: \`1.5px solid \${item.border}\`, borderRadius: 14, padding: '10px 12px' }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <b style={{ fontSize: 13, color: item.color }}>{item.trait}</b>
                  <span style={{ fontSize: 11, fontWeight: 800, padding: '1px 6px', borderRadius: 99, background: diff > 0 ? '#DCFCE7' : diff < 0 ? '#FEE2E2' : '#F1F5F9', color: diff > 0 ? '#166534' : diff < 0 ? '#991B1B' : '#64748B' }}>
                    {diff > 0 ? \`+\${diff} ↗\` : diff < 0 ? \`\${diff} ↘\` : 'Đều'}
                  </span>
                </div>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginTop: 4 }}>
                  <span style={{ fontSize: 20, fontWeight: 800, color: item.color }}>{thisCnt}</span>
                  <span style={{ fontSize: 11.5, color: '#64748B' }}>tuần này</span>
                  <span style={{ fontSize: 11.5, color: '#94A3B8', marginLeft: 'auto' }}>trước: {lastCnt}</span>
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </>
  )
}
\`\`\`

---

#### BƯỚC 6: NÂNG CẤP BẢNG ĐIỀU KHIỂN ADMIN (\`src/Admin.jsx\`)
Trong Tab Analytics (\`activeTab === 'analytics'\`):
1. Thêm Card: **Phân Tích Dữ Liệu Lớn Sticker & Phẩm Chất Theo Thời Gian (Longitudinal Big Data)**.
2. Grid hiển thị các phẩm chất toàn hệ thống bằng FontAwesome tone-sur-tone.
3. Nút bấm: \`✨ AI Phân Tích Tổng Quan Hệ Thống\` gọi \`handleAdminAiSummary\` để xuất báo cáo sư phạm vĩ mô cho ban quản trị.

\`\`\`jsx
<div className="admin-content-card" style={{ gridColumn: '1 / -1' }}>
  <div className="card-header-row">
    <div>
      <h3 className="section-title">
        <i className="fa-solid fa-chart-line" style={{ color: '#7C3AED', marginRight: 8 }} />
        Phân Tích Dữ Liệu Lớn Sticker & Phẩm Chất Theo Thời Gian (Longitudinal Big Data)
      </h3>
    </div>
    <button className="admin-pri-btn" onClick={handleAdminAiSummary} disabled={adminAnalyzing}>
      {adminAnalyzing ? 'Đang phân tích Big Data…' : '✨ AI Phân Tích Tổng Quan Hệ Thống'}
    </button>
  </div>
  {adminAiAnalysis && (
    <div style={{ background: '#FFFFFF', borderRadius: 12, padding: '14px 16px', border: '1px solid #E9D5FF', marginTop: 14, whiteSpace: 'pre-wrap' }}>
      {adminAiAnalysis}
    </div>
  )}
</div>
\`\`\`

---

#### BƯỚC 7: NÂNG CẤP SỔ DÁN HUY HIỆU VÀ CAROUSEL
1. Trong \`RewardSheet\` (\`src/App.jsx\`): Khi đổi quà chỉ reset \`stickers: 0\`, \`stickersList: []\`, bảo toàn \`stickerHistory\`.
2. Trong \`StickerBookSheet\` (\`src/App.jsx\`): Duyệt qua \`AVAILABLE_STICKERS\` và render icon FontAwesome tone-sur-tone:

\`\`\`jsx
<div
  style={{
    width: 44,
    height: 44,
    borderRadius: 14,
    background: unlocked ? '#FFFFFF' : '#E2E8F0',
    border: \`1.5px solid \${unlocked ? stk.border : '#CBD5E1'}\`,
    color: unlocked ? stk.color : '#94A3B8',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: 20,
  }}
>
  <i className={stk.fa || 'fa-solid fa-award'} />
</div>
\`\`\`

---

### TIÊU CHÍ NGHIỆM THU (VERIFICATION):
1. Chạy \`npm run build\` không có lỗi.
2. Sticker history không bị xóa khi nhận quà 10 sticker.
3. Bấm "AI Phân Tích Lộ Trình Cân Bằng" ở màn hình Báo cáo trả về chuẩn 3 phần có cấu trúc.
4. Mọi huy hiệu trên giao diện đều hiển thị chuẩn FontAwesome tone-sur-tone.`,
    createdAt: '2026-10-23 16:45',
    updatedAt: '2026-10-23 16:50',
  },
]

export default function TeamPromptSyncTab() {
  const [prompts, setPrompts] = useState(() => {
    try {
      const cached = localStorage.getItem(LOCAL_STORAGE_KEY)
      if (cached) {
        let list = JSON.parse(cached)
        // Lọc bỏ các demo prompt cũ, chỉ giữ prompt chuẩn của dự án
        list = list.filter((p) => !p.id.startsWith('tp_demo_'))
        const idx = list.findIndex((p) => p.id === 'tp_longitudinal_1')
        if (idx !== -1) {
          list[idx] = { ...INITIAL_TEAM_PROMPTS[0] }
        } else {
          list = [INITIAL_TEAM_PROMPTS[0], ...list]
        }
        localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(list))
        return list
      }
    } catch (e) {}
    return INITIAL_TEAM_PROMPTS
  })

  const [loading, setLoading] = useState(false)
  const [syncing, setSyncing] = useState(false)
  const [lastSyncTime, setLastSyncTime] = useState(null)
  const [search, setSearch] = useState('')
  const [filterCategory, setFilterCategory] = useState('all')
  const [filterRunStatus, setFilterRunStatus] = useState('all') // 'all' | 'ran' | 'pending'
  const [expandedMap, setExpandedMap] = useState({})

  // Modal / Form state
  const [isFormOpen, setIsFormOpen] = useState(false)
  const [editingId, setEditingId] = useState(null)
  const [formTitle, setFormTitle] = useState('')
  const [formCategory, setFormCategory] = useState('math')
  const [formTargetAi, setFormTargetAi] = useState('Claude 3.7 Sonnet')
  const [formAuthor, setFormAuthor] = useState(() => localStorage.getItem(LAST_AUTHOR_KEY) || 'Thành viên Team')
  const [formDetail, setFormDetail] = useState('')
  const [formIsRun, setFormIsRun] = useState(false)
  const [formRunBy, setFormRunBy] = useState('')
  const [formAiResult, setFormAiResult] = useState('')

  // Quick Test Playground state
  const [testingId, setTestingId] = useState(null)
  const [testResult, setTestResult] = useState(null)
  const [testRunning, setTestRunning] = useState(false)

  // 1. Đồng bộ ban đầu từ Cloud D1 KV
  useEffect(() => {
    fetchFromCloud()
  }, [])

  const fetchFromCloud = async () => {
    setLoading(true)
    try {
      const cloudData = await dbKvGet(TEAM_PROMPTS_KV_KEY)
      if (cloudData && Array.isArray(cloudData) && cloudData.length > 0) {
        setPrompts(cloudData)
        localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(cloudData))
        setLastSyncTime(new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit', second: '2-digit' }))
        toast('Đã đồng bộ prompts mới nhất từ Cloud D1 ☁️')
      } else {
        // Chưa có dữ liệu trên cloud -> ghi dữ liệu ban đầu lên
        await dbKvSet(TEAM_PROMPTS_KV_KEY, prompts)
        setLastSyncTime(new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }))
      }
    } catch (err) {
      console.warn('Load cloud prompts failed, using local cache:', err)
    } finally {
      setLoading(false)
    }
  }

  // 2. Lưu lên Cloud D1 KV & LocalStorage
  const savePromptsToCloud = async (newPromptsList, successMsg = 'Đã lưu & đồng bộ lên Cloud D1 ☁️') => {
    setSyncing(true)
    setPrompts(newPromptsList)
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(newPromptsList))
      await dbKvSet(TEAM_PROMPTS_KV_KEY, newPromptsList)
      setLastSyncTime(new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit', second: '2-digit' }))
      toast(successMsg)
    } catch (e) {
      toast('Lưu vào máy thành công (Mạng chậm khi đẩy lên Cloud)')
    } finally {
      setSyncing(false)
    }
  }

  // 3. Toggle trạng thái Đã chạy ở AI công ty trực tiếp
  const handleToggleRunStatus = async (item) => {
    const updatedStatus = !item.isRunCompanyAi
    const nowStr = new Date().toLocaleString('vi-VN', {
      hour: '2-digit',
      minute: '2-digit',
      day: '2-digit',
      month: '2-digit',
    })

    const updatedList = prompts.map((p) => {
      if (p.id === item.id) {
        return {
          ...p,
          isRunCompanyAi: updatedStatus,
          runAt: updatedStatus ? (p.runAt || nowStr) : '',
          runBy: updatedStatus ? (p.runBy || formAuthor || 'Thành viên Team') : '',
          updatedAt: nowStr,
        }
      }
      return p
    })

    await savePromptsToCloud(
      updatedList,
      updatedStatus
        ? `✅ Đã đánh dấu "ĐÃ CHẠY Ở AI CTY" cho: ${item.title.slice(0, 30)}…`
        : `⏳ Đã chuyển về "Chưa chạy" cho: ${item.title.slice(0, 30)}…`
    )
  }

  // 4. Mở form thêm mới
  const handleOpenAdd = () => {
    setEditingId(null)
    setFormTitle('')
    setFormCategory('math')
    setFormTargetAi('Claude 3.7 Sonnet')
    setFormDetail('')
    setFormIsRun(false)
    setFormRunBy('')
    setFormAiResult('')
    setIsFormOpen(true)
  }

  // 5. Mở form sửa
  const handleOpenEdit = (item) => {
    setEditingId(item.id)
    setFormTitle(item.title)
    setFormCategory(item.category || 'math')
    setFormTargetAi(item.targetAi || 'Claude 3.7 Sonnet')
    setFormAuthor(item.author || '')
    setFormDetail(item.promptDetail || '')
    setFormIsRun(!!item.isRunCompanyAi)
    setFormRunBy(item.runBy || '')
    setFormAiResult(item.aiResult || '')
    setIsFormOpen(true)
  }

  // 6. Xóa prompt
  const handleDelete = async (item) => {
    if (!window.confirm(`Bạn có chắc muốn xóa prompt: "${item.title}"?`)) return
    const updated = prompts.filter((p) => p.id !== item.id)
    await savePromptsToCloud(updated, 'Đã xóa prompt khỏi danh sách')
  }

  // 7. Lưu form (Thêm hoặc Sửa)
  const handleSaveForm = async (e) => {
    e?.preventDefault()
    if (!formTitle.trim()) {
      alert('Vui lòng nhập Tiêu đề Prompt!')
      return
    }
    if (!formDetail.trim()) {
      alert('Vui lòng nhập Nội dung chi tiết của Prompt!')
      return
    }

    localStorage.setItem(LAST_AUTHOR_KEY, formAuthor.trim() || 'Thành viên Team')

    const nowStr = new Date().toLocaleString('vi-VN', {
      hour: '2-digit',
      minute: '2-digit',
      day: '2-digit',
      month: '2-digit',
    })

    let updatedList = []

    if (editingId) {
      updatedList = prompts.map((p) => {
        if (p.id === editingId) {
          return {
            ...p,
            title: formTitle.trim(),
            category: formCategory,
            targetAi: formTargetAi,
            author: formAuthor.trim() || 'Thành viên Team',
            promptDetail: formDetail.trim(),
            isRunCompanyAi: formIsRun,
            runBy: formIsRun ? (formRunBy.trim() || formAuthor.trim() || 'Team') : '',
            runAt: formIsRun ? (p.runAt || nowStr) : '',
            aiResult: formAiResult.trim(),
            updatedAt: nowStr,
          }
        }
        return p
      })
    } else {
      const newPromptItem = {
        id: 'tp_' + Date.now(),
        title: formTitle.trim(),
        category: formCategory,
        targetAi: formTargetAi,
        author: formAuthor.trim() || 'Thành viên Team',
        promptDetail: formDetail.trim(),
        isRunCompanyAi: formIsRun,
        runBy: formIsRun ? (formRunBy.trim() || formAuthor.trim() || 'Team') : '',
        runAt: formIsRun ? nowStr : '',
        aiResult: formAiResult.trim(),
        createdAt: nowStr,
        updatedAt: nowStr,
      }
      updatedList = [newPromptItem, ...prompts]
    }

    await savePromptsToCloud(updatedList, editingId ? 'Đã cập nhật prompt thành công! ✨' : 'Đã gửi prompt mới lên bảng sync team! 🚀')
    setIsFormOpen(false)
  }

  // 8. Copy prompt 1 chạm
  const handleCopyPrompt = (text, title) => {
    navigator.clipboard.writeText(text)
    toast(`📋 Đã copy prompt: "${title.slice(0, 25)}…" vào clipboard!`)
  }

  // 9. Xuất danh sách Markdown để gửi Zalo/Slack cho team
  const handleExportSummary = () => {
    const lines = [
      `# 📋 BÁO CÁO ĐỒNG BỘ PROMPT TEAM (Cập nhật: ${new Date().toLocaleDateString('vi-VN')})`,
      `Tổng số: ${prompts.length} prompt | Đã chạy ở AI cty: ${metrics.ranCount} | Chờ chạy: ${metrics.pendingCount}`,
      '------------------------------------------------------------',
    ]

    prompts.forEach((p, idx) => {
      lines.push(`${idx + 1}. [${p.isRunCompanyAi ? '✅ ĐÃ RUN CTY' : '⏳ CHỜ RUN'}] ${p.title}`)
      lines.push(`   - Danh mục: ${p.category} | Model mục tiêu: ${p.targetAi}`)
      lines.push(`   - Người gửi: ${p.author} ${p.isRunCompanyAi ? `(Người check: ${p.runBy} lúc ${p.runAt})` : ''}`)
      if (p.aiResult) lines.push(`   - Kết quả/Feedback: ${p.aiResult}`)
      lines.push(`   - Nội dung tóm tắt: ${p.promptDetail.slice(0, 120).replace(/\n/g, ' ')}...`)
      lines.push('')
    })

    navigator.clipboard.writeText(lines.join('\n'))
    toast('📋 Đã copy toàn bộ bảng tổng hợp Markdown để gửi cho Team!')
  }

  // 10. Chạy thử nhanh qua AI Gateway
  const handleQuickTest = async (item) => {
    setTestingId(item.id)
    setTestRunning(true)
    setTestResult(null)
    const start = performance.now()
    try {
      const res = await fetch(`${AI_GATEWAY}/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [
            { role: 'system', content: item.promptDetail },
            { role: 'user', content: 'Hãy thực hiện mẫu theo yêu cầu trong prompt.' },
          ],
          max_tokens: 600,
          temperature: 0.3,
        }),
      })

      if (!res.ok) throw new Error('Gateway trả về mã lỗi HTTP ' + res.status)
      const data = await res.json()
      const elapsed = Math.round((performance.now() - start) / 1000)
      setTestResult({
        success: true,
        text: data.response || '(Không có phản hồi)',
        elapsed,
      })
      toast(`⚡ Đã chạy thử xong qua AI Gateway (${elapsed}s)`)
    } catch (err) {
      setTestResult({
        success: false,
        text: 'Lỗi: ' + err.message,
      })
      toast('Chạy thử thất bại: ' + err.message)
    } finally {
      setTestRunning(false)
    }
  }

  // Thống kê nhanh
  const metrics = useMemo(() => {
    const total = prompts.length
    const ranCount = prompts.filter((p) => p.isRunCompanyAi).length
    const pendingCount = total - ranCount
    const percent = total > 0 ? Math.round((ranCount / total) * 100) : 0
    return { total, ranCount, pendingCount, percent }
  }, [prompts])

  // Lọc dữ liệu hiển thị
  const filteredPrompts = useMemo(() => {
    return prompts.filter((p) => {
      // Tìm kiếm
      if (search.trim()) {
        const q = search.toLowerCase()
        const matchTitle = (p.title || '').toLowerCase().includes(q)
        const matchDetail = (p.promptDetail || '').toLowerCase().includes(q)
        const matchAuthor = (p.author || '').toLowerCase().includes(q)
        const matchModel = (p.targetAi || '').toLowerCase().includes(q)
        if (!matchTitle && !matchDetail && !matchAuthor && !matchModel) return false
      }
      // Lọc danh mục
      if (filterCategory !== 'all' && p.category !== filterCategory) return false
      // Lọc trạng thái run cty
      if (filterRunStatus === 'ran' && !p.isRunCompanyAi) return false
      if (filterRunStatus === 'pending' && p.isRunCompanyAi) return false

      return true
    })
  }, [prompts, search, filterCategory, filterRunStatus])

  return (
    <div className="prompt-studio-root" style={{ width: '100%', maxWidth: '100%', minWidth: 0, boxSizing: 'border-box' }}>
      {/* 🚀 HEADER BANNER & KPI STATS */}
      <div
        style={{
          background: 'linear-gradient(135deg, #1E1B4B 0%, #312E81 50%, #4338CA 100%)',
          borderRadius: 18,
          padding: '22px 26px',
          color: '#FFFFFF',
          boxShadow: '0 10px 30px -5px rgba(67, 56, 202, 0.3)',
          display: 'flex',
          flexDirection: 'column',
          gap: 18,
        }}
      >
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', flexWrap: 'wrap', gap: 14 }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
              <span style={{ fontSize: 28 }}>🚀</span>
              <h2 style={{ fontSize: 22, fontWeight: 800, margin: 0, letterSpacing: '-0.02em' }}>
                Bảng Đồng Bộ Prompt Team — AI Công Ty
              </h2>
              <span
                style={{
                  background: 'rgba(255, 255, 255, 0.15)',
                  backdropFilter: 'blur(10px)',
                  padding: '3px 10px',
                  borderRadius: 20,
                  fontSize: 12,
                  fontWeight: 700,
                  border: '1px solid rgba(255, 255, 255, 0.25)',
                }}
              >
                Syncup Hub
              </span>
            </div>
            <p style={{ margin: '6px 0 0', fontSize: 13.5, color: '#E0E7FF', maxWidth: 680, lineHeight: 1.5 }}>
              Không gian gửi, lưu trữ và theo dõi các Prompt đã chạy trên hệ thống AI của công ty (Claude, ChatGPT, Internal AI) để team phối hợp nhịp nhàng.
            </p>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
            <button
              onClick={fetchFromCloud}
              disabled={loading || syncing}
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: 6,
                padding: '8px 14px',
                borderRadius: 10,
                background: 'rgba(255, 255, 255, 0.12)',
                color: '#fff',
                border: '1px solid rgba(255, 255, 255, 0.25)',
                fontWeight: 700,
                fontSize: 12.5,
                cursor: 'pointer',
                transition: 'all 0.15s ease',
              }}
              title="Kéo dữ liệu mới nhất từ Cloud D1"
            >
              <span>{loading ? '⏳' : '🔄'}</span>
              <span>{loading ? 'Đang sync…' : 'Đồng bộ Cloud'}</span>
            </button>

            <button
              onClick={handleExportSummary}
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: 6,
                padding: '8px 14px',
                borderRadius: 10,
                background: 'rgba(255, 255, 255, 0.12)',
                color: '#fff',
                border: '1px solid rgba(255, 255, 255, 0.25)',
                fontWeight: 700,
                fontSize: 12.5,
                cursor: 'pointer',
              }}
              title="Copy tóm tắt Markdown để gửi Zalo/Slack"
            >
              <span>📋</span>
              <span>Xuất cho Team</span>
            </button>

            <button
              onClick={handleOpenAdd}
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: 7,
                padding: '9px 18px',
                borderRadius: 10,
                background: '#10B981',
                color: '#FFFFFF',
                border: 'none',
                fontWeight: 800,
                fontSize: 13.5,
                cursor: 'pointer',
                boxShadow: '0 4px 14px rgba(16, 185, 129, 0.4)',
                transition: 'transform 0.15s ease, background 0.15s ease',
              }}
            >
              <span style={{ fontSize: 16 }}>➕</span>
              <span>Gửi Prompt Mới Lên</span>
            </button>
          </div>
        </div>

        {/* BENTO KPI MINI BAR */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))',
            gap: 12,
            paddingTop: 8,
            borderTop: '1px solid rgba(255, 255, 255, 0.12)',
          }}
        >
          <div style={{ background: 'rgba(255, 255, 255, 0.08)', borderRadius: 12, padding: '10px 14px' }}>
            <div style={{ fontSize: 11.5, color: '#C7D2FE', fontWeight: 600 }}>TỔNG SỐ PROMPTS</div>
            <div style={{ fontSize: 22, fontWeight: 800, color: '#fff', marginTop: 2 }}>{metrics.total}</div>
          </div>
          <div style={{ background: 'rgba(16, 185, 129, 0.15)', borderRadius: 12, padding: '10px 14px', border: '1px solid rgba(16, 185, 129, 0.3)' }}>
            <div style={{ fontSize: 11.5, color: '#A7F3D0', fontWeight: 700 }}>✅ ĐÃ CHẠY Ở AI CTY</div>
            <div style={{ fontSize: 22, fontWeight: 800, color: '#34D399', marginTop: 2 }}>{metrics.ranCount}</div>
          </div>
          <div style={{ background: 'rgba(245, 158, 11, 0.15)', borderRadius: 12, padding: '10px 14px', border: '1px solid rgba(245, 158, 11, 0.3)' }}>
            <div style={{ fontSize: 11.5, color: '#FDE68A', fontWeight: 700 }}>⏳ CHỜ CHẠY TEST</div>
            <div style={{ fontSize: 22, fontWeight: 800, color: '#FBBF24', marginTop: 2 }}>{metrics.pendingCount}</div>
          </div>
          <div style={{ background: 'rgba(255, 255, 255, 0.08)', borderRadius: 12, padding: '10px 14px' }}>
            <div style={{ fontSize: 11.5, color: '#C7D2FE', fontWeight: 600 }}>TIẾN ĐỘ THỰC HIỆN</div>
            <div style={{ fontSize: 22, fontWeight: 800, color: '#fff', marginTop: 2 }}>{metrics.percent}%</div>
          </div>
        </div>

        {lastSyncTime && (
          <div style={{ fontSize: 11.5, color: 'rgba(255, 255, 255, 0.65)', display: 'flex', alignItems: 'center', gap: 6 }}>
            <span>☁️</span>
            <span>Đồng bộ Cloud lần cuối: <b>{lastSyncTime}</b></span>
            {syncing && <span style={{ color: '#FCD34D' }}>• Đang lưu dữ liệu…</span>}
          </div>
        )}
      </div>

      {/* 🔍 FILTER & SEARCH BAR */}
      <div
        style={{
          background: '#FFFFFF',
          borderRadius: 14,
          border: '1px solid #E2E8F0',
          padding: '12px 16px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          flexWrap: 'wrap',
          gap: 12,
          boxShadow: '0 2px 8px rgba(0, 0, 0, 0.03)',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, flex: 1, minWidth: 260 }}>
          <span style={{ fontSize: 16 }}>🔍</span>
          <input
            type="text"
            placeholder="Tìm theo tiêu đề, nội dung, người tạo, model AI…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            style={{
              width: '100%',
              border: 'none',
              outline: 'none',
              fontSize: 13.5,
              color: '#0F172A',
              background: 'transparent',
            }}
          />
          {search && (
            <button
              onClick={() => setSearch('')}
              style={{ background: 'none', border: 'none', color: '#94A3B8', cursor: 'pointer', fontSize: 14 }}
            >
              ✕
            </button>
          )}
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
          {/* Lọc trạng thái check cty */}
          <div style={{ display: 'flex', alignItems: 'center', background: '#F1F5F9', padding: 3, borderRadius: 9 }}>
            <button
              type="button"
              onClick={() => setFilterRunStatus('all')}
              style={{
                border: 'none',
                padding: '5px 11px',
                borderRadius: 7,
                fontSize: 12,
                fontWeight: 700,
                cursor: 'pointer',
                background: filterRunStatus === 'all' ? '#FFFFFF' : 'transparent',
                color: filterRunStatus === 'all' ? '#0F172A' : '#64748B',
                boxShadow: filterRunStatus === 'all' ? '0 1px 3px rgba(0,0,0,0.08)' : 'none',
              }}
            >
              Tất cả ({metrics.total})
            </button>
            <button
              type="button"
              onClick={() => setFilterRunStatus('ran')}
              style={{
                border: 'none',
                padding: '5px 11px',
                borderRadius: 7,
                fontSize: 12,
                fontWeight: 700,
                cursor: 'pointer',
                background: filterRunStatus === 'ran' ? '#10B981' : 'transparent',
                color: filterRunStatus === 'ran' ? '#FFFFFF' : '#059669',
                boxShadow: filterRunStatus === 'ran' ? '0 1px 3px rgba(0,0,0,0.08)' : 'none',
              }}
            >
              ✅ Đã chạy ({metrics.ranCount})
            </button>
            <button
              type="button"
              onClick={() => setFilterRunStatus('pending')}
              style={{
                border: 'none',
                padding: '5px 11px',
                borderRadius: 7,
                fontSize: 12,
                fontWeight: 700,
                cursor: 'pointer',
                background: filterRunStatus === 'pending' ? '#F59E0B' : 'transparent',
                color: filterRunStatus === 'pending' ? '#FFFFFF' : '#D97706',
                boxShadow: filterRunStatus === 'pending' ? '0 1px 3px rgba(0,0,0,0.08)' : 'none',
              }}
            >
              ⏳ Chưa chạy ({metrics.pendingCount})
            </button>
          </div>

          {/* Lọc danh mục */}
          <select
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
            style={{
              padding: '6px 10px',
              borderRadius: 8,
              border: '1px solid #CBD5E1',
              fontSize: 12.5,
              fontWeight: 600,
              color: '#334155',
              background: '#fff',
              outline: 'none',
              cursor: 'pointer',
            }}
          >
            {PROMPT_CATEGORIES.map((c) => (
              <option key={c.id} value={c.id}>
                {c.icon} {c.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* 📝 DANH SÁCH PROMPTS CARDS */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        {filteredPrompts.length === 0 ? (
          <div
            style={{
              background: '#FFFFFF',
              borderRadius: 16,
              border: '1px dashed #CBD5E1',
              padding: '48px 24px',
              textAlign: 'center',
              color: '#64748B',
            }}
          >
            <div style={{ fontSize: 44, marginBottom: 12 }}>📭</div>
            <h3 style={{ fontSize: 16, fontWeight: 700, color: '#334155', margin: '0 0 6px' }}>
              Chưa có prompt nào phù hợp với bộ lọc
            </h3>
            <p style={{ fontSize: 13, margin: '0 0 16px', color: '#94A3B8' }}>
              Bấm nút bên dưới để gửi prompt mới lên cho team sync cùng nhé!
            </p>
            <button
              onClick={handleOpenAdd}
              style={{
                padding: '8px 18px',
                borderRadius: 9,
                background: '#4F46E5',
                color: '#fff',
                border: 'none',
                fontWeight: 700,
                fontSize: 13,
                cursor: 'pointer',
              }}
            >
              ➕ Thêm Prompt Mới Ngay
            </button>
          </div>
        ) : (
          filteredPrompts.map((item, idx) => {
            const isExpanded = !!expandedMap[item.id]
            const isTestingThis = testingId === item.id
            const catObj = PROMPT_CATEGORIES.find((c) => c.id === item.category) || { name: 'Khác', icon: '🏷️' }

            return (
              <div
                key={item.id}
                style={{
                  background: '#FFFFFF',
                  borderRadius: 16,
                  border: item.isRunCompanyAi ? '1.5px solid #A7F3D0' : '1.5px solid #FDE68A',
                  boxShadow: '0 2px 10px rgba(0, 0, 0, 0.04)',
                  overflow: 'hidden',
                  transition: 'all 0.15s ease',
                }}
              >
                {/* CARD HEADER */}
                <div
                  style={{
                    padding: '14px 18px',
                    background: item.isRunCompanyAi
                      ? 'linear-gradient(90deg, #F0FDF4 0%, #FFFFFF 100%)'
                      : 'linear-gradient(90deg, #FFFBEB 0%, #FFFFFF 100%)',
                    borderBottom: '1px solid #F1F5F9',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    flexWrap: 'wrap',
                    gap: 12,
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
                    <span style={{ fontSize: 13, fontWeight: 800, color: '#64748B' }}>#{idx + 1}</span>

                    {/* Tag danh mục */}
                    <span
                      style={{
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: 4,
                        padding: '3px 9px',
                        borderRadius: 6,
                        background: '#EEF2FF',
                        border: '1px solid #C7D2FE',
                        color: '#4338CA',
                        fontSize: 12,
                        fontWeight: 700,
                      }}
                    >
                      <span>{catObj.icon}</span>
                      <span>{catObj.name}</span>
                    </span>

                    {/* Model AI công ty mục tiêu */}
                    <span
                      style={{
                        padding: '3px 9px',
                        borderRadius: 6,
                        background: '#F1F5F9',
                        color: '#334155',
                        fontSize: 11.5,
                        fontWeight: 600,
                        border: '1px solid #E2E8F0',
                      }}
                    >
                      🤖 {item.targetAi || 'AI Công ty'}
                    </span>

                    {/* 🎯 NÚT TOGGLE CHECK ĐÃ CHẠY Ở AI CTY CHƯA */}
                    <button
                      type="button"
                      onClick={() => handleToggleRunStatus(item)}
                      style={{
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: 6,
                        padding: '4px 12px',
                        borderRadius: 20,
                        border: item.isRunCompanyAi ? '1.5px solid #10B981' : '1.5px dashed #F59E0B',
                        background: item.isRunCompanyAi ? '#ECFDF5' : '#FFFBEB',
                        color: item.isRunCompanyAi ? '#065F46' : '#B45309',
                        fontWeight: 800,
                        fontSize: 12,
                        cursor: 'pointer',
                        transition: 'all 0.15s ease',
                      }}
                      title="Bấm để đổi trạng thái đã chạy thử ở AI công ty hay chưa"
                    >
                      <span>{item.isRunCompanyAi ? '✅' : '⏳'}</span>
                      <span>{item.isRunCompanyAi ? 'ĐÃ CHẠY Ở AI CÔNG TY' : 'CHƯA CHẠY Ở AI CTY (Bấm để check)'}</span>
                    </button>
                  </div>

                  {/* THAO TÁC (Sửa, Xóa, Copy) */}
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    <button
                      onClick={() => handleCopyPrompt(item.promptDetail, item.title)}
                      style={{
                        padding: '5px 10px',
                        borderRadius: 7,
                        background: '#F8FAFC',
                        border: '1px solid #CBD5E1',
                        color: '#334155',
                        fontSize: 12,
                        fontWeight: 700,
                        cursor: 'pointer',
                      }}
                      title="Copy toàn bộ nội dung prompt"
                    >
                      📋 Copy
                    </button>

                    <button
                      onClick={() => handleOpenEdit(item)}
                      style={{
                        padding: '5px 10px',
                        borderRadius: 7,
                        background: '#F8FAFC',
                        border: '1px solid #CBD5E1',
                        color: '#2563EB',
                        fontSize: 12,
                        fontWeight: 700,
                        cursor: 'pointer',
                      }}
                      title="Chỉnh sửa thông tin"
                    >
                      ✏️ Sửa
                    </button>

                    <button
                      onClick={() => handleDelete(item)}
                      style={{
                        padding: '5px 10px',
                        borderRadius: 7,
                        background: '#FEF2F2',
                        border: '1px solid #FECACA',
                        color: '#DC2626',
                        fontSize: 12,
                        fontWeight: 700,
                        cursor: 'pointer',
                      }}
                      title="Xóa prompt này"
                    >
                      🗑️
                    </button>
                  </div>
                </div>

                {/* CARD BODY */}
                <div style={{ padding: '16px 18px', display: 'flex', flexDirection: 'column', gap: 12 }}>
                  <div>
                    <h3 style={{ fontSize: 16.5, fontWeight: 800, color: '#0F172A', margin: '0 0 6px', lineHeight: 1.35 }}>
                      {item.title}
                    </h3>

                    <div style={{ fontSize: 12, color: '#64748B', display: 'flex', alignItems: 'center', gap: 12, flexWrap: 'wrap' }}>
                      <span>👤 Người gửi: <b>{item.author || 'Thành viên Team'}</b></span>
                      <span>🕒 Tạo: {item.createdAt || 'Mới đây'}</span>
                      {item.isRunCompanyAi && item.runBy && (
                        <span style={{ color: '#059669', fontWeight: 600 }}>
                          • Check bởi: <b>{item.runBy}</b> ({item.runAt})
                        </span>
                      )}
                    </div>
                  </div>

                  {/* PROMPT DETAIL BOX */}
                  <div
                    style={{
                      position: 'relative',
                      background: '#F8FAFC',
                      borderRadius: 10,
                      border: '1px solid #E2E8F0',
                      padding: '12px 14px',
                    }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
                      <span style={{ fontSize: 11.5, fontWeight: 800, color: '#475569', textTransform: 'uppercase', letterSpacing: '0.04em' }}>
                        📄 Nội dung Prompt Detail:
                      </span>
                      <span style={{ fontSize: 11, color: '#94A3B8' }}>
                        {item.promptDetail.length} ký tự
                      </span>
                    </div>

                    <pre
                      style={{
                        margin: 0,
                        fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace',
                        fontSize: 12.5,
                        color: '#1E293B',
                        lineHeight: 1.5,
                        whiteSpace: 'pre-wrap',
                        wordBreak: 'break-word',
                        maxHeight: isExpanded ? 'none' : '110px',
                        overflow: 'hidden',
                      }}
                    >
                      {item.promptDetail}
                    </pre>

                    {item.promptDetail.length > 200 && (
                      <button
                        type="button"
                        onClick={() => setExpandedMap((prev) => ({ ...prev, [item.id]: !prev[item.id] }))}
                        style={{
                          marginTop: 6,
                          background: 'none',
                          border: 'none',
                          color: '#4F46E5',
                          fontSize: 12,
                          fontWeight: 700,
                          cursor: 'pointer',
                          padding: 0,
                        }}
                      >
                        {isExpanded ? '▲ Thu gọn' : '▼ Xem đầy đủ prompt…'}
                      </button>
                    )}
                  </div>

                  {/* PHẦN GHI CHÚ KẾT QUẢ AI CÔNG TY */}
                  {item.aiResult && (
                    <div
                      style={{
                        background: '#ECFDF5',
                        borderLeft: '4px solid #10B981',
                        borderRadius: '0 8px 8px 0',
                        padding: '10px 14px',
                        fontSize: 12.5,
                        color: '#065F46',
                      }}
                    >
                      <b style={{ display: 'block', marginBottom: 2 }}>📝 Phản hồi & Kết quả chạy ở AI công ty:</b>
                      <span style={{ whiteSpace: 'pre-wrap' }}>{item.aiResult}</span>
                    </div>
                  )}

                  {/* QUICK TEST FOOTER */}
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 10, paddingTop: 4 }}>
                    <button
                      type="button"
                      disabled={testRunning}
                      onClick={() => handleQuickTest(item)}
                      style={{
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: 6,
                        padding: '6px 12px',
                        borderRadius: 8,
                        background: '#EEF2FF',
                        border: '1px solid #C7D2FE',
                        color: '#4338CA',
                        fontSize: 12,
                        fontWeight: 700,
                        cursor: 'pointer',
                      }}
                      title="Chạy thử mẫu prompt này trực tiếp qua AI Gateway"
                    >
                      <span>⚡</span>
                      <span>{isTestingThis && testRunning ? 'Đang chạy thử…' : 'Chạy thử qua AI Gateway'}</span>
                    </button>

                    <span style={{ fontSize: 11.5, color: '#94A3B8' }}>
                      Cập nhật lần cuối: {item.updatedAt || item.createdAt}
                    </span>
                  </div>

                  {/* KẾT QUẢ TEST THỬ REALTIME NẾU CÓ */}
                  {isTestingThis && testResult && (
                    <div
                      style={{
                        marginTop: 4,
                        background: testResult.success ? '#F0FDF4' : '#FEF2F2',
                        borderRadius: 10,
                        border: testResult.success ? '1px solid #BBF7D0' : '1px solid #FECACA',
                        padding: '12px',
                        fontSize: 12.5,
                      }}
                    >
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6, fontWeight: 700 }}>
                        <span style={{ color: testResult.success ? '#15803D' : '#B91C1C' }}>
                          {testResult.success ? `✨ Kết quả trả về (${testResult.elapsed}s):` : '❌ Có lỗi khi gọi Gateway:'}
                        </span>
                        <button
                          onClick={() => {
                            setTestingId(null)
                            setTestResult(null)
                          }}
                          style={{ background: 'none', border: 'none', color: '#94A3B8', cursor: 'pointer' }}
                        >
                          Đóng ✕
                        </button>
                      </div>
                      <pre style={{ margin: 0, whiteSpace: 'pre-wrap', wordBreak: 'break-word', color: '#1E293B', fontFamily: 'inherit' }}>
                        {testResult.text}
                      </pre>
                    </div>
                  )}
                </div>
              </div>
            )
          })
        )}
      </div>

      {/* 🚀 MODAL / FORM THÊM & SỬA PROMPT */}
      {isFormOpen && (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            background: 'rgba(15, 23, 42, 0.65)',
            backdropFilter: 'blur(5px)',
            zIndex: 9999,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            padding: 16,
          }}
          onClick={(e) => {
            if (e.target === e.currentTarget) setIsFormOpen(false)
          }}
        >
          <div
            style={{
              background: '#FFFFFF',
              borderRadius: 18,
              width: '100%',
              maxWidth: 700,
              maxHeight: '92vh',
              overflowY: 'auto',
              boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.25)',
              border: '1px solid #E2E8F0',
              padding: '24px 28px',
              display: 'flex',
              flexDirection: 'column',
              gap: 18,
            }}
          >
            {/* MODAL HEADER */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <h3 style={{ margin: 0, fontSize: 18, fontWeight: 800, color: '#0F172A' }}>
                  {editingId ? '✏️ Chỉnh Sửa Prompt Sync' : '🚀 Gửi Prompt Mới Lên Cho Team'}
                </h3>
                <p style={{ margin: '3px 0 0', fontSize: 12.5, color: '#64748B' }}>
                  Thông tin sẽ được tự động lưu lên Cloud D1 để toàn bộ team cùng xem và theo dõi.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsFormOpen(false)}
                style={{
                  background: '#F1F5F9',
                  border: 'none',
                  borderRadius: '50%',
                  width: 32,
                  height: 32,
                  fontSize: 16,
                  cursor: 'pointer',
                  color: '#64748B',
                }}
              >
                ✕
              </button>
            </div>

            {/* FORM BODY */}
            <form onSubmit={handleSaveForm} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
              {/* Tiêu đề prompt */}
              <div>
                <label style={{ display: 'block', fontSize: 13, fontWeight: 700, color: '#334155', marginBottom: 5 }}>
                  Tiêu đề Prompt <span style={{ color: '#EF4444' }}>*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="VD: Prompt Singapore CPA Toán lớp 3 giải bài toán 2 bước"
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  style={{
                    width: '100%',
                    padding: '10px 12px',
                    borderRadius: 9,
                    border: '1.5px solid #CBD5E1',
                    fontSize: 13.5,
                    fontWeight: 600,
                    outline: 'none',
                    boxSizing: 'border-box',
                  }}
                />
              </div>

              {/* Danh mục & Model AI mục tiêu */}
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                <div>
                  <label style={{ display: 'block', fontSize: 12.5, fontWeight: 700, color: '#334155', marginBottom: 5 }}>
                    Danh mục chuyên môn
                  </label>
                  <select
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value)}
                    style={{
                      width: '100%',
                      padding: '9px 11px',
                      borderRadius: 8,
                      border: '1.5px solid #CBD5E1',
                      fontSize: 13,
                      fontWeight: 600,
                      background: '#fff',
                      outline: 'none',
                      boxSizing: 'border-box',
                    }}
                  >
                    {PROMPT_CATEGORIES.filter((c) => c.id !== 'all').map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.icon} {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label style={{ display: 'block', fontSize: 12.5, fontWeight: 700, color: '#334155', marginBottom: 5 }}>
                    AI Model công ty mục tiêu
                  </label>
                  <select
                    value={formTargetAi}
                    onChange={(e) => setFormTargetAi(e.target.value)}
                    style={{
                      width: '100%',
                      padding: '9px 11px',
                      borderRadius: 8,
                      border: '1.5px solid #CBD5E1',
                      fontSize: 13,
                      fontWeight: 600,
                      background: '#fff',
                      outline: 'none',
                      boxSizing: 'border-box',
                    }}
                  >
                    {COMPANY_AI_MODELS.map((m) => (
                      <option key={m} value={m}>
                        🤖 {m}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Người gửi */}
              <div>
                <label style={{ display: 'block', fontSize: 12.5, fontWeight: 700, color: '#334155', marginBottom: 5 }}>
                  Tên người gửi / Thành viên tạo
                </label>
                <input
                  type="text"
                  placeholder="VD: Huyền, Nam AI, Linh..."
                  value={formAuthor}
                  onChange={(e) => setFormAuthor(e.target.value)}
                  style={{
                    width: '100%',
                    padding: '8px 12px',
                    borderRadius: 8,
                    border: '1.5px solid #CBD5E1',
                    fontSize: 13,
                    outline: 'none',
                    boxSizing: 'border-box',
                  }}
                />
              </div>

              {/* Prompt Detail Textarea */}
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 5 }}>
                  <label style={{ fontSize: 13, fontWeight: 700, color: '#334155' }}>
                    Nội dung chi tiết Prompt <span style={{ color: '#EF4444' }}>*</span>
                  </label>
                  <span style={{ fontSize: 11.5, color: '#64748B' }}>
                    {formDetail.length} ký tự
                  </span>
                </div>
                <textarea
                  required
                  rows={8}
                  placeholder="Dán toàn bộ System Prompt / Instructions chi tiết tại đây (hỗ trợ {{mon}}, {{lop}}, {{de_bai}}...)"
                  value={formDetail}
                  onChange={(e) => setFormDetail(e.target.value)}
                  style={{
                    width: '100%',
                    padding: '10px 12px',
                    borderRadius: 8,
                    border: '1.5px solid #CBD5E1',
                    fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace',
                    fontSize: 12.5,
                    lineHeight: 1.5,
                    outline: 'none',
                    boxSizing: 'border-box',
                    resize: 'vertical',
                  }}
                />
              </div>

              {/* 🎯 CHECKLIST: ĐÃ RUN Ở AI CÔNG TY CHƯA */}
              <div
                style={{
                  background: formIsRun ? '#ECFDF5' : '#FFFBEB',
                  borderRadius: 10,
                  border: formIsRun ? '1.5px solid #10B981' : '1.5px solid #FCD34D',
                  padding: '12px 14px',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: 10,
                }}
              >
                <label style={{ display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer' }}>
                  <input
                    type="checkbox"
                    checked={formIsRun}
                    onChange={(e) => setFormIsRun(e.target.checked)}
                    style={{ width: 18, height: 18, accentColor: '#10B981', cursor: 'pointer' }}
                  />
                  <div>
                    <span style={{ fontSize: 13.5, fontWeight: 800, color: formIsRun ? '#065F46' : '#92400E' }}>
                      {formIsRun ? '✅ Đã chạy thử nghiệm ở AI công ty' : '⏳ Chưa chạy thử nghiệm ở AI công ty'}
                    </span>
                    <span style={{ display: 'block', fontSize: 11.5, color: '#64748B' }}>
                      (Tích vào đây nếu team đã test prompt này trên Claude / ChatGPT / AI của cty)
                    </span>
                  </div>
                </label>

                {formIsRun && (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 8, paddingTop: 6, borderTop: '1px solid rgba(16, 185, 129, 0.2)' }}>
                    <div>
                      <label style={{ fontSize: 12, fontWeight: 700, color: '#065F46', display: 'block', marginBottom: 3 }}>
                        Người đã chạy test:
                      </label>
                      <input
                        type="text"
                        placeholder="VD: Huyền, Nam..."
                        value={formRunBy}
                        onChange={(e) => setFormRunBy(e.target.value)}
                        style={{
                          width: '100%',
                          padding: '6px 10px',
                          borderRadius: 6,
                          border: '1px solid #A7F3D0',
                          fontSize: 12.5,
                          boxSizing: 'border-box',
                        }}
                      />
                    </div>

                    <div>
                      <label style={{ fontSize: 12, fontWeight: 700, color: '#065F46', display: 'block', marginBottom: 3 }}>
                        Nhận xét / Kết quả chạy thử:
                      </label>
                      <textarea
                        rows={2}
                        placeholder="Ghi chú kết quả: Model chạy ổn không, có lỗi JSON không, cần tinh chỉnh gì không..."
                        value={formAiResult}
                        onChange={(e) => setFormAiResult(e.target.value)}
                        style={{
                          width: '100%',
                          padding: '6px 10px',
                          borderRadius: 6,
                          border: '1px solid #A7F3D0',
                          fontSize: 12.5,
                          boxSizing: 'border-box',
                          resize: 'vertical',
                        }}
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* FOOTER BUTTONS */}
              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10, marginTop: 6 }}>
                <button
                  type="button"
                  onClick={() => setIsFormOpen(false)}
                  style={{
                    padding: '9px 16px',
                    borderRadius: 9,
                    background: '#F1F5F9',
                    border: '1px solid #CBD5E1',
                    color: '#475569',
                    fontWeight: 700,
                    fontSize: 13,
                    cursor: 'pointer',
                  }}
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  disabled={syncing}
                  style={{
                    padding: '9px 20px',
                    borderRadius: 9,
                    background: '#4F46E5',
                    color: '#FFFFFF',
                    border: 'none',
                    fontWeight: 800,
                    fontSize: 13,
                    cursor: 'pointer',
                    boxShadow: '0 4px 12px rgba(79, 70, 229, 0.3)',
                  }}
                >
                  {syncing ? 'Đang lưu…' : '💾 Lưu & Đồng bộ Cloud'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
