import { useState, useEffect, useMemo, useRef } from 'react'
import {
  DEFAULT_PROMPTS,
  getActivePrompts,
  setActivePrompts,
  renderPrompt,
  PROMPT_HISTORY_KEY,
  routePedagogyMethod,
} from './promptStudio'
import { dbKvGet, dbKvSet, AI_GATEWAY } from './api'
import { toast } from './utils'

export const PARAM_CONFIG = {
  '{{lop}}': {
    name: 'Khối lớp',
    bg: '#ECFDF5',
    border: '#10B981',
    text: '#047857',
    markBg: 'rgba(16, 185, 129, 0.28)',
    underline: '#10B981',
    icon: '🎒',
  },
  '{{sach}}': {
    name: 'Bộ sách',
    bg: '#EFF6FF',
    border: '#3B82F6',
    text: '#1D4ED8',
    markBg: 'rgba(59, 130, 246, 0.28)',
    underline: '#3B82F6',
    icon: '📚',
  },
  '{{giong}}': {
    name: 'Giọng gợi ý',
    bg: '#F5F3FF',
    border: '#8B5CF6',
    text: '#6D28D9',
    markBg: 'rgba(139, 92, 246, 0.28)',
    underline: '#8B5CF6',
    icon: '🗣️',
  },
  '{{mo_ta_giong}}': {
    name: 'Mô tả giọng',
    bg: '#FDF4FF',
    border: '#D946EF',
    text: '#A21CAF',
    markBg: 'rgba(217, 70, 239, 0.28)',
    underline: '#D946EF',
    icon: '✨',
  },
  '{{de_bai}}': {
    name: 'Đề bài toán',
    bg: '#FFFBEB',
    border: '#F59E0B',
    text: '#B45309',
    markBg: 'rgba(245, 158, 11, 0.35)',
    underline: '#F59E0B',
    icon: '📝',
  },
  '{{khung_ghi_chu}}': {
    name: 'Khung ghi chú',
    bg: '#FFF1F2',
    border: '#F43F5E',
    text: '#BE123C',
    markBg: 'rgba(244, 63, 94, 0.28)',
    underline: '#F43F5E',
    icon: '📌',
  },
  '{{ghi_chu}}': {
    name: 'Lời nhắn phụ huynh',
    bg: '#F0FDFA',
    border: '#14B8A6',
    text: '#0F766E',
    markBg: 'rgba(20, 184, 166, 0.28)',
    underline: '#14B8A6',
    icon: '💬',
  },
  '{{mon}}': {
    name: 'Môn học',
    bg: '#E0F2FE',
    border: '#0284C7',
    text: '#0369A1',
    markBg: 'rgba(2, 132, 199, 0.28)',
    underline: '#0284C7',
    icon: '📘',
  },
  '{{dang_bai}}': {
    name: 'Dạng bài',
    bg: '#FEF3C7',
    border: '#D97706',
    text: '#B45309',
    markBg: 'rgba(217, 119, 6, 0.28)',
    underline: '#D97706',
    icon: '🎯',
  },
  '{{loi_hay_gap}}': {
    name: 'Lỗi hay gặp',
    bg: '#FFE4E6',
    border: '#E11D48',
    text: '#BE123C',
    markBg: 'rgba(225, 29, 72, 0.28)',
    underline: '#E11D48',
    icon: '⚠️',
  },
  '{{doan_phuong_phap}}': {
    name: 'Phương pháp Router',
    bg: '#F3E8FF',
    border: '#9333EA',
    text: '#7E22CE',
    markBg: 'rgba(147, 51, 234, 0.28)',
    underline: '#9333EA',
    icon: '💡',
  },
}

export function getParamStyle(tag) {
  return (
    PARAM_CONFIG[tag] || {
      name: tag.replace(/[{}]/g, ''),
      bg: '#F1F5F9',
      border: '#64748B',
      text: '#334155',
      markBg: 'rgba(100, 116, 139, 0.22)',
      underline: '#64748B',
      icon: '🏷️',
    }
  )
}

export default function PromptStudioTab() {
  const [prompts, setPrompts] = useState(() => getActivePrompts())
  const [selectedKey, setSelectedKey] = useState('p3_explain')
  const [drafts, setDrafts] = useState(() => {
    const init = {}
    const active = getActivePrompts()
    Object.keys(DEFAULT_PROMPTS).forEach((k) => {
      init[k] = active[k]?.template || DEFAULT_PROMPTS[k].template
    })
    return init
  })

  // Secret admin key (nhập tạm trong tab, không lưu local cố định)
  const [adminKey, setAdminKey] = useState('')
  const [showKeyInput, setShowKeyInput] = useState(false)
  const [versionNote, setVersionNote] = useState('')

  // Lịch sử phiên bản
  const [history, setHistory] = useState(() => {
    try {
      const raw = localStorage.getItem(PROMPT_HISTORY_KEY)
      return raw ? JSON.parse(raw) : []
    } catch (e) {
      return []
    }
  })
  const [showHistoryModal, setShowHistoryModal] = useState(false)

  // Chạy thử (Test runner)
  const [testMon, setTestMon] = useState('Toán')
  const [testLop, setTestLop] = useState('Lớp 2')
  const [testSach, setTestSach] = useState('Kết nối tri thức')
  const [testGiong, setTestGiong] = useState('Dịu dàng')
  const [testDeBai, setTestDeBai] = useState('Mẹ mua 9 quả táo. Mẹ cho Na 3 quả. Hỏi mẹ còn mấy quả táo?')
  const [testGhiChu, setTestGhiChu] = useState('Con chưa học phép nhân, giảng bằng phép cộng/trừ nhé.')
  const [testRunning, setTestRunning] = useState(false)
  const [testOutput, setTestOutput] = useState(null)
  const [testChecks, setTestChecks] = useState([])
  const [testDuration, setTestDuration] = useState(0)

  // Load cloud prompts on mount
  useEffect(() => {
    dbKvGet('prompt_studio:config').then((cloudVal) => {
      if (cloudVal && typeof cloudVal === 'object') {
        const merged = setActivePrompts(cloudVal)
        setPrompts(merged)
        setDrafts((prev) => {
          const updated = { ...prev }
          Object.keys(DEFAULT_PROMPTS).forEach((k) => {
            if (merged[k]?.template) updated[k] = merged[k].template
          })
          return updated
        })
      }
    })
  }, [])

  const curDef = DEFAULT_PROMPTS[selectedKey] || DEFAULT_PROMPTS.p3_explain
  const curDraft = drafts[selectedKey] || ''

  // Kiểm tra tính hợp lệ của prompt hiện tại
  const validation = useMemo(() => {
    const missing = []
    if (curDef.requiredVars) {
      curDef.requiredVars.forEach((v) => {
        if (!curDraft.includes(v)) missing.push(v)
      })
    }
    const isTooLong = curDraft.length > 12000
    const isEmpty = !curDraft.trim()
    const isError = missing.length > 0 || isTooLong || isEmpty
    return { missing, isTooLong, isEmpty, isError }
  }, [curDef, curDraft])

  // Trạng thái các prompt
  const getPromptStatus = (k) => {
    const def = DEFAULT_PROMPTS[k]
    const d = drafts[k] || ''
    // Kiểm tra lỗi
    if (def.requiredVars) {
      for (const v of def.requiredVars) {
        if (!d.includes(v)) return { label: 'lỗi', color: '#EF4444' }
      }
    }
    if (!d.trim() || d.length > 12000) return { label: 'lỗi', color: '#EF4444' }

    // Chưa lưu (khác với server/prompts hiện tại)
    if (d !== (prompts[k]?.template || def.template)) {
      return { label: 'chưa lưu', color: '#F59E0B' }
    }
    // Đã tùy chỉnh (khác mặc định hệ thống)
    if (d !== def.template) {
      return { label: 'đã tùy chỉnh', color: '#10B981' }
    }
    return null
  }

  const textareaRef = useRef(null)
  const backdropRef = useRef(null)
  const [editorMode, setEditorMode] = useState('edit') // 'edit' | 'preview'

  // Chèn biến chính xác vào vị trí con trỏ chuột
  const handleInsertParam = (paramTag) => {
    const el = textareaRef.current
    if (!el) {
      setDrafts((prev) => ({
        ...prev,
        [selectedKey]: (prev[selectedKey] || '') + ' ' + paramTag,
      }))
      toast(`Đã chèn biến ${paramTag}`)
      return
    }

    const start = el.selectionStart ?? el.value.length
    const end = el.selectionEnd ?? el.value.length
    const currentVal = el.value || ''
    const newVal = currentVal.substring(0, start) + paramTag + currentVal.substring(end)

    setDrafts((prev) => ({
      ...prev,
      [selectedKey]: newVal,
    }))

    // Nếu đang ở tab preview, chuyển lại edit để người dùng thấy con trỏ
    if (editorMode !== 'edit') {
      setEditorMode('edit')
    }

    // Giữ focus và đưa con trỏ ra ngay sau biến vừa chèn
    setTimeout(() => {
      el.focus()
      const nextPos = start + paramTag.length
      el.setSelectionRange(nextPos, nextPos)
      if (backdropRef.current) {
        backdropRef.current.scrollTop = el.scrollTop
      }
    }, 15)

    const style = getParamStyle(paramTag)
    toast(`Đã chèn ${style.icon} ${paramTag} vào đúng vị trí con trỏ 🎯`)
  }

  // Tạo lớp highlight màu cho các biến trong Editor
  const renderHighlightedBackdrop = (text) => {
    if (!text) return ''
    const escaped = text
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')

    return escaped.replace(/\{\{([a-zA-Z0-9_]+)\}\}/g, (match) => {
      const style = getParamStyle(match)
      return `<mark style="background: ${style.markBg}; color: transparent; border-bottom: 2.5px solid ${style.underline}; border-radius: 4px; font-weight: 700; padding: 0 1px;">${match}</mark>`
    })
  }

  // Hiển thị trực quan từng biến với màu sắc và icon riêng biệt
  const renderVisualParts = (text) => {
    if (!text) return null
    const parts = text.split(/(\{\{[a-zA-Z0-9_]+\}\})/g)
    return parts.map((part, idx) => {
      if (part.startsWith('{{') && part.endsWith('}}')) {
        const style = getParamStyle(part)
        return (
          <span
            key={idx}
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: 4,
              padding: '2px 8px',
              margin: '0 2px',
              borderRadius: 6,
              background: style.bg,
              border: `1.5px solid ${style.border}`,
              color: style.text,
              fontWeight: 800,
              fontSize: 12.5,
              verticalAlign: 'baseline',
              boxShadow: '0 1px 2px rgba(0,0,0,0.05)',
            }}
            title={`${style.name} (${part})`}
          >
            <span>{style.icon}</span>
            <span>{part}</span>
            <small style={{ fontSize: 10.5, opacity: 0.85, fontWeight: 700 }}>· {style.name}</small>
          </span>
        )
      }
      return <span key={idx}>{part}</span>
    })
  }

  // Bỏ thay đổi
  const handleDiscardCurrent = () => {
    setDrafts((prev) => ({
      ...prev,
      [selectedKey]: prompts[selectedKey]?.template || curDef.template,
    }))
    toast('Đã hoàn tác thay đổi về bản đang áp dụng')
  }

  // Về mặc định
  const handleResetToDefault = () => {
    setDrafts((prev) => ({
      ...prev,
      [selectedKey]: curDef.template,
    }))
    toast('Đã đưa prompt về bản mặc định (Nhớ bấm Lưu để áp dụng nhé)')
  }

  // Chạy thử prompt
  const handleRunTest = async () => {
    if (validation.isError) {
      toast('Không thể chạy thử vì prompt đang có lỗi!')
      return
    }
    setTestRunning(true)
    setTestOutput(null)
    setTestChecks([])
    const start = performance.now()

    try {
      let finalPrompt = curDraft
      if (selectedKey === 'p3_explain') {
        let moTaGiong = 'dịu dàng, khích lệ'
        if (testGiong === 'Vui nhộn') moTaGiong = 'vui tươi, hài hước nhẹ'
        else if (testGiong === 'Ngắn gọn') moTaGiong = 'câu ngắn, ít chữ'

        let khungGhiChu = ''
        if (testGhiChu.trim()) {
          const subDraft = drafts.p3b_parent_note_explain || DEFAULT_PROMPTS.p3b_parent_note_explain.template
          khungGhiChu = subDraft.replace(/\{\{ghi_chu\}\}/g, testGhiChu.trim().slice(0, 200))
        }

        const routed = routePedagogyMethod({
          mon: testMon,
          lop: testLop,
          dang_bai: testMon === 'Toán' ? 'Toán có lời văn phép tính' : 'Bài học tiểu học',
        })

        finalPrompt = finalPrompt
          .replace(/\{\{mon\}\}/g, testMon)
          .replace(/\{\{lop\}\}/g, testLop)
          .replace(/\{\{sach\}\}/g, testSach)
          .replace(/\{\{bo_sach\}\}/g, testSach)
          .replace(/\{\{dang_bai\}\}/g, testMon === 'Toán' ? 'Toán có lời văn hai bước tính' : 'Đọc hiểu và vận dụng')
          .replace(/\{\{loi_hay_gap\}\}/g, 'Bố mẹ hay sốt ruột làm hộ phép tính trước khi con kịp hiểu đề')
          .replace(/\{\{doan_phuong_phap\}\}/g, routed.doan_phuong_phap)
          .replace(/\{\{giong\}\}/g, testGiong)
          .replace(/\{\{mo_ta_giong\}\}/g, moTaGiong)
          .replace(/\{\{de_bai\}\}/g, testDeBai)
          .replace(/\{\{khung_ghi_chu\}\}/g, khungGhiChu)
      } else if (selectedKey === 'p4_chat') {
        let khungGhiChu = ''
        if (testGhiChu.trim()) {
          const subDraft = drafts.p4b_parent_note_chat || DEFAULT_PROMPTS.p4b_parent_note_chat.template
          khungGhiChu = subDraft.replace(/\{\{ghi_chu\}\}/g, testGhiChu.trim().slice(0, 200))
        }
        finalPrompt = finalPrompt
          .replace(/\{\{lop\}\}/g, testLop)
          .replace(/\{\{sach\}\}/g, testSach)
          .replace(/\{\{de_bai\}\}/g, testDeBai)
          .replace(/\{\{khung_ghi_chu\}\}/g, khungGhiChu)
      } else if (selectedKey === 'p6_practice') {
        finalPrompt = finalPrompt
          .replace(/\{\{lop\}\}/g, testLop)
          .replace(/\{\{sach\}\}/g, testSach)
          .replace(/\{\{de_bai\}\}/g, testDeBai)
      }

      const res = await fetch(`${AI_GATEWAY}/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [
            { role: 'system', content: finalPrompt },
            { role: 'user', content: selectedKey === 'p6_practice' ? 'Tạo bài luyện thêm' : 'Phân tích bài này' },
          ],
          max_tokens: 1500,
          temperature: 0.3,
        }),
      })

      const elapsed = Math.round((performance.now() - start) / 1000)
      setTestDuration(elapsed)

      if (!res.ok) throw new Error('Gateway trả về lỗi HTTP ' + res.status)
      const j = await res.json()
      const rawText = j.response || ''
      setTestOutput(rawText)

      // Kiểm định tự động
      const checks = []
      let parsed = null
      try {
        const m = rawText.match(/\{[\s\S]*\}/)
        if (m) parsed = JSON.parse(m[0])
      } catch (e) {}

      checks.push({ label: 'JSON hợp lệ', pass: !!parsed })
      if (selectedKey === 'p3_explain') {
        const stepList = parsed?.cac_bac || parsed?.steps || []
        checks.push({ label: 'Có 2 đến 4 bậc câu hỏi gợi mở', pass: stepList.length >= 2 && stepList.length <= 4 })
        checks.push({ label: 'Có đáp án đối chiếu cho bố mẹ', pass: !!(parsed?.dap_an_cuoi_cho_me || parsed?.answer) })
        checks.push({ label: 'Có bài anh em cùng dạng', pass: !!(parsed?.bai_anh_em || parsed?.brotherProblem) })
        checks.push({ label: 'Có trò chơi 5 phút ôn bài', pass: !!(parsed?.tro_choi_5_phut || parsed?.fiveMinGame) })
        checks.push({ label: 'Có câu "Con dạy lại mẹ"', pass: !!(parsed?.con_day_lai_me || parsed?.teachBack) })
      } else if (selectedKey === 'p6_practice') {
        checks.push({ label: 'Có text đề bài mới', pass: !!(parsed && parsed.text) })
        checks.push({ label: 'Có đáp án cho bố mẹ', pass: !!(parsed && parsed.answer) })
      }
      checks.push({ label: 'Thời gian chạy dưới 30 giây', pass: elapsed < 30 })

      setTestChecks(checks)
    } catch (e) {
      setTestOutput('Lỗi: ' + e.message)
      setTestChecks([{ label: 'Thực thi thành công', pass: false }])
    } finally {
      setTestRunning(false)
    }
  }

  // Lưu phiên bản lên Cloudflare D1
  const handleSaveAll = async () => {
    // 1. Kiểm tra khoá
    if (!adminKey.trim()) {
      setShowKeyInput(true)
      toast('⚠️ Nhập khoá quản trị prompt trước khi lưu')
      return
    }

    // 2. Kiểm tra còn prompt lỗi không
    const errorPrompts = []
    Object.keys(DEFAULT_PROMPTS).forEach((k) => {
      const st = getPromptStatus(k)
      if (st && st.label === 'lỗi') errorPrompts.push(DEFAULT_PROMPTS[k].name)
    })
    if (errorPrompts.length > 0) {
      alert(`Còn prompt chưa hợp lệ:\n- ${errorPrompts.join('\n- ')}\nVui lòng sửa lại các biến bắt buộc trước khi lưu!`)
      return
    }

    // 3. Chuẩn bị payload
    const updatedPrompts = {}
    Object.keys(DEFAULT_PROMPTS).forEach((k) => {
      updatedPrompts[k] = {
        ...DEFAULT_PROMPTS[k],
        template: drafts[k],
        updatedAt: new Date().toISOString(),
      }
    })

    const note = versionNote.trim() || `Cập nhật ngày ${new Date().toLocaleDateString('vi-VN')}`
    const record = {
      versionId: 'ver_' + Date.now(),
      note,
      createdAt: new Date().toISOString(),
      prompts: updatedPrompts,
    }

    // 4. Lưu lên D1
    const ok = await dbKvSet('prompt_studio:config', updatedPrompts)
    if (ok) {
      setActivePrompts(updatedPrompts)
      setPrompts(updatedPrompts)
      
      // Cập nhật lịch sử (tối đa 30 bản ghi)
      const newHist = [record, ...history].slice(0, 30)
      setHistory(newHist)
      try {
        localStorage.setItem(PROMPT_HISTORY_KEY, JSON.stringify(newHist))
      } catch (e) {}

      setVersionNote('')
      setShowKeyInput(false)
      toast('🎉 Đã lưu cấu hình Prompt Studio thành công! Mọi gia đình sẽ nhận bản mới ở lần mở app tiếp theo.')
    } else {
      toast('❌ Lỗi kết nối lưu Cloudflare D1!')
    }
  }

  // Khôi phục từ lịch sử
  const handleRestoreVersion = (ver) => {
    if (!ver || !ver.prompts) return
    const restored = {}
    Object.keys(DEFAULT_PROMPTS).forEach((k) => {
      restored[k] = ver.prompts[k]?.template || DEFAULT_PROMPTS[k].template
    })
    setDrafts(restored)
    setShowHistoryModal(false)
    toast(`Đã tải lại bản: "${ver.note}". Bạn kiểm tra và bấm Lưu để áp dụng nhé!`)
  }

  return (
    <div className="prompt-studio-root" style={{ display: 'flex', flexDirection: 'column', gap: 16, width: '100%', maxWidth: '100%', minWidth: 0, boxSizing: 'border-box' }}>
      {/* HEADER BANNER */}
      <div className="prompt-studio-banner" style={{ background: 'linear-gradient(135deg, #1E1B4B 0%, #312E81 100%)', padding: '16px 20px', borderRadius: 16, color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 12, width: '100%', maxWidth: '100%', boxSizing: 'border-box' }}>
        <div style={{ minWidth: 0, flex: 1 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
            <span style={{ fontSize: 24 }}>📝</span>
            <h3 style={{ margin: 0, fontSize: 18, fontWeight: 800 }}>Prompt Studio — Quản trị câu chữ AI</h3>
            <span style={{ background: '#4338CA', fontSize: 11, padding: '2px 8px', borderRadius: 999, fontWeight: 700 }}>ZERO CODE DEPLOY</span>
          </div>
          <p style={{ margin: '4px 0 0', fontSize: 13, color: '#C7D2FE', lineHeight: 1.4 }}>
            Sửa câu chữ app dùng để dặn AI mà không cần lập trình viên build lại app. Bấm Lưu để áp dụng toàn hệ thống.
          </p>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap', flexShrink: 0 }}>
          <button
            className="admin-btn sm"
            style={{ background: 'rgba(255,255,255,0.15)', borderColor: 'rgba(255,255,255,0.3)', color: '#fff' }}
            onClick={() => setShowHistoryModal(true)}
          >
            🕘 Lịch sử phiên bản ({history.length})
          </button>
          <button
            className="admin-btn sm"
            style={{ background: '#10B981', borderColor: '#059669', color: '#fff', fontWeight: 800 }}
            onClick={() => setShowKeyInput(true)}
          >
            💾 Lưu cấu hình prompt
          </button>
        </div>
      </div>

      {/* WORKSPACE DUAL-PANE */}
      <div className="prompt-studio-dual-pane" style={{ display: 'grid', gridTemplateColumns: '260px minmax(0, 1fr)', gap: 16, minHeight: 650, width: '100%', maxWidth: '100%', minWidth: 0, boxSizing: 'border-box' }}>
        {/* LEFT COLUMN: DANH SÁCH 8 PROMPTS */}
        <div className="prompt-studio-sidebar" style={{ background: '#fff', borderRadius: 16, border: '1px solid #E2E8F0', padding: 12, display: 'flex', flexDirection: 'column', gap: 6, boxShadow: '0 2px 8px rgba(0,0,0,0.04)', minWidth: 0, boxSizing: 'border-box' }}>
          <span style={{ fontSize: 12, fontWeight: 800, color: '#64748B', padding: '4px 8px', textTransform: 'uppercase', letterSpacing: 0.5 }}>
            Danh sách 8 Prompts
          </span>

          {Object.keys(DEFAULT_PROMPTS).map((k) => {
            const item = DEFAULT_PROMPTS[k]
            const isSelected = selectedKey === k
            const status = getPromptStatus(k)

            return (
              <button
                key={k}
                onClick={() => setSelectedKey(k)}
                style={{
                  textAlign: 'left',
                  padding: '10px 12px',
                  borderRadius: 12,
                  border: isSelected ? '2px solid var(--plum)' : '1px solid #F1F5F9',
                  background: isSelected ? 'var(--plum-tint)' : '#F8FAFC',
                  cursor: 'pointer',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: 3,
                  transition: 'all .15s',
                  boxSizing: 'border-box',
                  width: '100%',
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 4 }}>
                  <b style={{ fontSize: 13, color: isSelected ? 'var(--plum-deep)' : '#1E293B', lineHeight: 1.3 }}>{item.name}</b>
                  {status && (
                    <span style={{ fontSize: 10.5, fontWeight: 700, padding: '2px 6px', borderRadius: 999, background: status.color, color: '#fff', flexShrink: 0 }}>
                      {status.label}
                    </span>
                  )}
                </div>
                <span style={{ fontSize: 11.5, color: '#64748B', lineHeight: 1.3 }}>{item.desc}</span>
              </button>
            )
          })}
        </div>

        {/* RIGHT COLUMN: EDITOR & TEST BENCH */}
        <div className="prompt-studio-main" style={{ display: 'flex', flexDirection: 'column', gap: 16, minWidth: 0, maxWidth: '100%', boxSizing: 'border-box' }}>
          {/* EDITOR CARD */}
          <div className="prompt-studio-card" style={{ background: '#fff', borderRadius: 16, border: '1px solid #E2E8F0', padding: 18, display: 'flex', flexDirection: 'column', gap: 12, boxShadow: '0 2px 8px rgba(0,0,0,0.04)', minWidth: 0, maxWidth: '100%', boxSizing: 'border-box' }}>
            <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', flexWrap: 'wrap', gap: 12, width: '100%', maxWidth: '100%', boxSizing: 'border-box' }}>
              <div style={{ minWidth: 0, flex: 1 }}>
                <b style={{ fontSize: 16, color: '#0F172A', display: 'block', lineHeight: 1.3 }}>{curDef.name}</b>
                <div style={{ fontSize: 12.5, color: '#64748B', marginTop: 2, lineHeight: 1.4 }}>{curDef.desc}</div>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap', flexShrink: 0 }}>
                {/* VIEW MODE TOGGLE */}
                <div style={{ display: 'inline-flex', background: '#F1F5F9', padding: 2, borderRadius: 8, border: '1px solid #E2E8F0' }}>
                  <button
                    type="button"
                    className="admin-btn sm"
                    style={{
                      background: editorMode === 'edit' ? '#FFFFFF' : 'transparent',
                      color: editorMode === 'edit' ? '#0F172A' : '#64748B',
                      border: 'none',
                      boxShadow: editorMode === 'edit' ? '0 1px 3px rgba(0,0,0,0.08)' : 'none',
                      fontWeight: 700,
                      padding: '4px 10px',
                      cursor: 'pointer',
                    }}
                    onClick={() => setEditorMode('edit')}
                  >
                    ✏️ Soạn thảo
                  </button>
                  <button
                    type="button"
                    className="admin-btn sm"
                    style={{
                      background: editorMode === 'preview' ? '#FFFFFF' : 'transparent',
                      color: editorMode === 'preview' ? '#0F172A' : '#64748B',
                      border: 'none',
                      boxShadow: editorMode === 'preview' ? '0 1px 3px rgba(0,0,0,0.08)' : 'none',
                      fontWeight: 700,
                      padding: '4px 10px',
                      cursor: 'pointer',
                    }}
                    onClick={() => setEditorMode('preview')}
                  >
                    👁️ Xem nổi bật biến
                  </button>
                </div>

                <button
                  className="admin-btn sm"
                  style={{ background: '#F1F5F9', color: '#475569' }}
                  onClick={handleDiscardCurrent}
                  title="Hủy các sửa đổi chưa lưu"
                >
                  ↶ Bỏ thay đổi
                </button>
                <button
                  className="admin-btn sm"
                  style={{ background: '#FEF2F2', borderColor: '#FECACA', color: '#DC2626' }}
                  onClick={handleResetToDefault}
                  title="Đưa về bản mẫu ban đầu của app"
                >
                  ↺ Về bản mặc định
                </button>
              </div>
            </div>

            {/* TEXTAREA EDITOR & PREVIEW */}
            {editorMode === 'edit' ? (
              <div
                style={{
                  position: 'relative',
                  width: '100%',
                  maxWidth: '100%',
                  borderRadius: 12,
                  border: validation.isError ? '1.5px solid #EF4444' : '1.5px solid #CBD5E1',
                  background: '#FFFFFF',
                  overflow: 'hidden',
                  boxShadow: 'inset 0 1px 3px rgba(0,0,0,0.02)',
                  boxSizing: 'border-box',
                }}
              >
                {/* BACKDROP HIGHLIGHTER (MÀU BIẾN CHẠY PHÍA SAU) */}
                <div
                  ref={backdropRef}
                  aria-hidden="true"
                  dangerouslySetInnerHTML={{ __html: renderHighlightedBackdrop(curDraft) + '<br/>' }}
                  style={{
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    right: 0,
                    bottom: 0,
                    width: '100%',
                    maxWidth: '100%',
                    padding: '12px 14px',
                    margin: 0,
                    fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace',
                    fontSize: 13,
                    lineHeight: 1.55,
                    whiteSpace: 'pre-wrap',
                    wordBreak: 'break-word',
                    overflowWrap: 'break-word',
                    color: 'transparent',
                    pointerEvents: 'none',
                    overflowY: 'hidden',
                    overflowX: 'hidden',
                    boxSizing: 'border-box',
                  }}
                />

                {/* TEXTAREA THỰC TẾ (TRONG SUỐT ĐỂ LỘ MÀU BIẾN) */}
                <textarea
                  ref={textareaRef}
                  value={curDraft}
                  onChange={(e) => setDrafts({ ...drafts, [selectedKey]: e.target.value })}
                  onScroll={(e) => {
                    if (backdropRef.current) {
                      backdropRef.current.scrollTop = e.target.scrollTop
                      backdropRef.current.scrollLeft = e.target.scrollLeft
                    }
                  }}
                  rows={14}
                  style={{
                    position: 'relative',
                    zIndex: 1,
                    width: '100%',
                    maxWidth: '100%',
                    padding: '12px 14px',
                    margin: 0,
                    borderRadius: 12,
                    border: 'none',
                    outline: 'none',
                    fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace',
                    fontSize: 13,
                    lineHeight: 1.55,
                    color: '#1E293B',
                    caretColor: '#2563EB',
                    background: 'transparent',
                    resize: 'vertical',
                    boxSizing: 'border-box',
                    whiteSpace: 'pre-wrap',
                    wordBreak: 'break-word',
                    overflowWrap: 'break-word',
                  }}
                />

                <span
                  style={{
                    position: 'absolute',
                    right: 12,
                    bottom: 12,
                    zIndex: 2,
                    fontSize: 11,
                    color: curDraft.length > 12000 ? '#EF4444' : '#94A3B8',
                    fontWeight: 600,
                    pointerEvents: 'none',
                    background: 'rgba(255,255,255,0.9)',
                    padding: '2px 6px',
                    borderRadius: 4,
                    border: '1px solid #E2E8F0',
                  }}
                >
                  {curDraft.length} / 12,000 ký tự
                </span>
              </div>
            ) : (
              /* PREVIEW CHẾ ĐỘ NỔI BẬT BIẾN */
              <div
                style={{
                  minHeight: 280,
                  maxHeight: 460,
                  overflowY: 'auto',
                  overflowX: 'hidden',
                  width: '100%',
                  maxWidth: '100%',
                  padding: '14px 16px',
                  borderRadius: 12,
                  border: '1.5px solid #CBD5E1',
                  background: '#F8FAFC',
                  fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace',
                  fontSize: 13,
                  lineHeight: 1.65,
                  whiteSpace: 'pre-wrap',
                  wordBreak: 'break-word',
                  overflowWrap: 'break-word',
                  color: '#334155',
                  boxSizing: 'border-box',
                }}
              >
                {renderVisualParts(curDraft)}
              </div>
            )}

            {/* ERROR ALERT */}
            {validation.isError && (
              <div style={{ background: '#FEF2F2', border: '1px solid #FCA5A5', padding: '8px 12px', borderRadius: 8, color: '#B91C1C', fontSize: 12.5, display: 'flex', gap: 6, alignItems: 'center', width: '100%', boxSizing: 'border-box' }}>
                <span>⚠️</span>
                <span>
                  {validation.missing.length > 0
                    ? `Thiếu chỗ điền bắt buộc: ${validation.missing.join(', ')}`
                    : validation.isEmpty
                    ? 'Prompt không được để trống'
                    : 'Prompt quá dài (tối đa 12,000 ký tự)'}
                </span>
              </div>
            )}

            {/* AVAILABLE VARIABLES WITH ENHANCED COLOR & CURSOR INSERTION */}
            {curDef.variables && curDef.variables.length > 0 && (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8, paddingTop: 4, width: '100%', maxWidth: '100%', boxSizing: 'border-box' }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 6, width: '100%' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6, flexWrap: 'wrap' }}>
                    <span style={{ fontSize: 12.5, fontWeight: 800, color: '#1E293B' }}>
                      🎯 Các biến có thể chèn vào vị trí con trỏ chuột:
                    </span>
                    <span style={{ fontSize: 11.5, color: '#64748B' }}>
                      (Bấm biến để chèn tự động vào đúng chỗ con trỏ đang đứng)
                    </span>
                  </div>
                  <div style={{ fontSize: 11, color: '#64748B' }}>
                    <span style={{ color: '#10B981', fontWeight: 800 }}>✓</span> Đã có &nbsp;
                    <span style={{ color: '#EF4444', fontWeight: 800 }}>+</span> Chưa chèn
                  </div>
                </div>

                <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap', width: '100%', maxWidth: '100%', boxSizing: 'border-box' }}>
                  {curDef.variables.map((v) => {
                    const isPresent = curDraft.includes(v)
                    const isRequired = curDef.requiredVars.includes(v)
                    const style = getParamStyle(v)
                    return (
                      <button
                        key={v}
                        type="button"
                        onMouseDown={(e) => e.preventDefault()}
                        onClick={() => handleInsertParam(v)}
                        style={{
                          display: 'inline-flex',
                          alignItems: 'center',
                          gap: 5,
                          padding: '5px 10px',
                          borderRadius: 8,
                          fontSize: 12,
                          fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace',
                          fontWeight: 700,
                          border: isPresent
                            ? `1.5px solid ${style.border}`
                            : isRequired
                            ? '1.5px dashed #EF4444'
                            : `1.5px dashed ${style.border}`,
                          background: isPresent ? style.bg : '#FFFFFF',
                          color: style.text,
                          cursor: 'pointer',
                          transition: 'all 0.15s ease',
                          boxShadow: isPresent ? '0 1px 2px rgba(0,0,0,0.05)' : 'none',
                          boxSizing: 'border-box',
                          maxWidth: '100%',
                        }}
                        title={`${style.name} — Bấm để chèn tại vị trí con trỏ chuột`}
                      >
                        <span style={{ fontSize: 13 }}>{style.icon}</span>
                        <span>{v}</span>
                        <span style={{ fontSize: 10, opacity: 0.85, fontWeight: 600 }}>
                          ({style.name})
                        </span>
                        <span
                          style={{
                            fontSize: 11,
                            marginLeft: 3,
                            fontWeight: 800,
                            color: isPresent ? '#059669' : isRequired ? '#DC2626' : '#94A3B8',
                          }}
                        >
                          {isPresent ? '✓' : '+'}
                        </span>
                      </button>
                    )
                  })}
                </div>
              </div>
            )}
          </div>

          {/* TEST BENCH (CHẠY THỬ) */}
          <div className="prompt-studio-card" style={{ background: '#fff', borderRadius: 16, border: '1px solid #E2E8F0', padding: 18, display: 'flex', flexDirection: 'column', gap: 12, boxShadow: '0 2px 8px rgba(0,0,0,0.04)', minWidth: 0, maxWidth: '100%', boxSizing: 'border-box' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 10, width: '100%' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <span style={{ fontSize: 18 }}>🧪</span>
                <b style={{ fontSize: 15, color: '#0F172A' }}>Chạy thử prompt (Test Bench)</b>
              </div>
              <button
                className="admin-btn sm"
                style={{ background: 'var(--plum)', color: '#fff', fontWeight: 800 }}
                onClick={handleRunTest}
                disabled={testRunning || validation.isError}
              >
                {testRunning ? '⏳ Đang gọi AI thử nghiệm…' : '▶ Chạy thử nghiệm'}
              </button>
            </div>

            {/* TEST INPUTS */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(130px, 1fr))', gap: 8, width: '100%', maxWidth: '100%', boxSizing: 'border-box' }}>
              <div>
                <label style={{ fontSize: 11, fontWeight: 700, color: '#64748B' }}>Môn học:</label>
                <select className="field" style={{ fontSize: 13, padding: 6, width: '100%', boxSizing: 'border-box' }} value={testMon} onChange={(e) => setTestMon(e.target.value)}>
                  {['Toán', 'Tiếng Việt', 'Tiếng Anh'].map((x) => <option key={x} value={x}>{x}</option>)}
                </select>
              </div>
              <div>
                <label style={{ fontSize: 11, fontWeight: 700, color: '#64748B' }}>Lớp:</label>
                <select className="field" style={{ fontSize: 13, padding: 6, width: '100%', boxSizing: 'border-box' }} value={testLop} onChange={(e) => setTestLop(e.target.value)}>
                  {['Lớp 1', 'Lớp 2', 'Lớp 3', 'Lớp 4', 'Lớp 5'].map((x) => <option key={x} value={x}>{x}</option>)}
                </select>
              </div>
              <div>
                <label style={{ fontSize: 11, fontWeight: 700, color: '#64748B' }}>Bộ sách:</label>
                <select className="field" style={{ fontSize: 13, padding: 6, width: '100%', boxSizing: 'border-box' }} value={testSach} onChange={(e) => setTestSach(e.target.value)}>
                  {['Kết nối tri thức', 'Chân trời sáng tạo', 'Cánh Diều'].map((x) => <option key={x} value={x}>{x}</option>)}
                </select>
              </div>
              <div>
                <label style={{ fontSize: 11, fontWeight: 700, color: '#64748B' }}>Giọng:</label>
                <select className="field" style={{ fontSize: 13, padding: 6, width: '100%', boxSizing: 'border-box' }} value={testGiong} onChange={(e) => setTestGiong(e.target.value)}>
                  {['Nhẹ nhàng', 'Vui nhộn', 'Ngắn gọn'].map((x) => <option key={x} value={x}>{x}</option>)}
                </select>
              </div>
            </div>

            <div>
              <label style={{ fontSize: 11, fontWeight: 700, color: '#64748B' }}>Đề bài mẫu:</label>
              <input
                className="field"
                style={{ fontSize: 13, padding: 8, width: '100%', boxSizing: 'border-box' }}
                value={testDeBai}
                onChange={(e) => setTestDeBai(e.target.value)}
                placeholder="Nhập đề bài mẫu để test..."
              />
            </div>

            <div>
              <label style={{ fontSize: 11, fontWeight: 700, color: '#64748B' }}>Ghi chú phụ huynh (nếu có):</label>
              <input
                className="field"
                style={{ fontSize: 13, padding: 8, width: '100%', boxSizing: 'border-box' }}
                value={testGhiChu}
                onChange={(e) => setTestGhiChu(e.target.value)}
                placeholder="Nhập ghi chú phụ huynh để thử nghiệm prompt 3b..."
              />
            </div>

            {/* TEST CHECKS */}
            {testChecks.length > 0 && (
              <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', padding: '10px 12px', background: '#F8FAFC', borderRadius: 10, border: '1px solid #E2E8F0', width: '100%', boxSizing: 'border-box' }}>
                {testChecks.map((c, i) => (
                  <span key={i} style={{ fontSize: 12, fontWeight: 700, color: c.pass ? '#059669' : '#DC2626', display: 'flex', alignItems: 'center', gap: 4 }}>
                    {c.pass ? '✓' : '✗'} {c.label}
                  </span>
                ))}
                <span style={{ fontSize: 12, color: '#64748B', marginLeft: 'auto' }}>
                  ⏱️ {testDuration} giây
                </span>
              </div>
            )}

            {/* TEST OUTPUT DISPLAY */}
            {testOutput && (
              <div style={{ marginTop: 4, width: '100%', boxSizing: 'border-box' }}>
                <label style={{ fontSize: 11, fontWeight: 700, color: '#64748B' }}>Kết quả AI trả về:</label>
                <pre style={{ maxHeight: 220, overflowY: 'auto', overflowX: 'auto', whiteSpace: 'pre-wrap', wordBreak: 'break-word', background: '#0F172A', color: '#38BDF8', padding: 12, borderRadius: 10, fontSize: 12, lineHeight: 1.5, margin: '4px 0 0', width: '100%', boxSizing: 'border-box' }}>
                  {testOutput}
                </pre>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* MODAL NHẬP KHÓA QUẢN TRỊ KHI LƯU */}
      {showKeyInput && (
        <div className="admin-modal-bg" onClick={() => setShowKeyInput(false)}>
          <div className="admin-modal" style={{ maxWidth: 440 }} onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <span style={{ fontSize: 24 }}>🔐</span>
                <h3 style={{ margin: 0, fontSize: 16 }}>Xác thực Lưu cấu hình Prompt</h3>
              </div>
              <button className="close-btn" onClick={() => setShowKeyInput(false)}>✕</button>
            </div>
            <div className="modal-body" style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              <p style={{ margin: 0, fontSize: 13, color: '#475569' }}>
                Để bảo vệ hệ thống, bạn cần nhập <b>Khoá quản trị prompt</b> (secret `PROMPT_ADMIN_KEY` trên Cloudflare).
              </p>
              <div>
                <label style={{ fontSize: 12, fontWeight: 700 }}>Khoá quản trị:</label>
                <input
                  type="password"
                  className="field"
                  style={{ marginTop: 4 }}
                  placeholder="Nhập khoá quản trị..."
                  value={adminKey}
                  onChange={(e) => setAdminKey(e.target.value)}
                />
              </div>
              <div>
                <label style={{ fontSize: 12, fontWeight: 700 }}>Ghi chú phiên bản (tuỳ chọn):</label>
                <input
                  type="text"
                  className="field"
                  style={{ marginTop: 4 }}
                  placeholder="VD: Rút ngắn câu hỏi dưới 25 chữ, gợi ý đồ vật..."
                  value={versionNote}
                  onChange={(e) => setVersionNote(e.target.value)}
                />
              </div>
            </div>
            <div className="modal-footer" style={{ display: 'flex', gap: 8 }}>
              <button className="admin-btn ghost" onClick={() => setShowKeyInput(false)}>Hủy</button>
              <button className="admin-btn" style={{ background: '#10B981', color: '#fff', flex: 1 }} onClick={handleSaveAll}>
                Xác nhận & Lưu ngay
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL LỊCH SỬ PHIÊN BẢN */}
      {showHistoryModal && (
        <div className="admin-modal-bg" onClick={() => setShowHistoryModal(false)}>
          <div className="admin-modal" style={{ maxWidth: 600 }} onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <span style={{ fontSize: 24 }}>🕘</span>
                <h3 style={{ margin: 0, fontSize: 16 }}>Lịch sử 30 phiên bản Prompt gần nhất</h3>
              </div>
              <button className="close-btn" onClick={() => setShowHistoryModal(false)}>✕</button>
            </div>
            <div className="modal-body" style={{ maxHeight: 420, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 10 }}>
              {history.length === 0 ? (
                <div style={{ textAlign: 'center', padding: 30, color: '#94A3B8' }}>
                  Chưa có lịch sử lưu nào. Mọi phiên bản lưu sẽ được hiển thị tại đây.
                </div>
              ) : (
                history.map((ver, idx) => (
                  <div
                    key={ver.versionId || idx}
                    style={{
                      padding: '10px 14px',
                      borderRadius: 10,
                      background: '#F8FAFC',
                      border: '1px solid #E2E8F0',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                    }}
                  >
                    <div>
                      <b style={{ fontSize: 13.5, color: '#1E293B' }}>{ver.note}</b>
                      <div style={{ fontSize: 11.5, color: '#64748B' }}>
                        {new Date(ver.createdAt).toLocaleString('vi-VN')}
                      </div>
                    </div>
                    <button
                      className="admin-btn sm"
                      style={{ background: '#3B82F6', color: '#fff' }}
                      onClick={() => handleRestoreVersion(ver)}
                    >
                      Khôi phục bản này
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
